<?php

/*
Plugin Name: Picasa2Wordpress
Plugin URI: http://clyang.net/blog/2009/02/06/128
Plugin Improvement: http://panshinspace.com/?p=274
Description: Integrade Picasa client with wordpress, which allows user upload the photos to wordpress via Picasa directly
Version: 1.0
Author: Cheng-Lin Yang
Improvement Author: Panshin Yuri
Author URI: http://clyang.net/blog/
Improvement Author URI: http://panshinspace.com/?cat=20
*/

define('WP_ADMIN', true);
require_once('../wp-load.php');
require_once('includes/admin.php');

session_start();
//Start the session to store POST data
if(!is_user_logged_in()){
    $_SESSION['POST'] = $_POST;
}else if(is_user_logged_in() && $_POST){
    $_SESSION['POST'] = $_POST;
}
require_once('admin.php');
require_once("xmlHandler.class");
?>

<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/>
<script type="text/javascript" src="http://panshinspace.com/wp-includes/js/jquery/jquery.js?ver=1.3.2"></script>
<script type="text/javascript" src="picasascript.js"></script>
<link rel="STYLESHEET" type="text/css" href="picasastyle.css">
</head>

<body>
<div class="page-wrapper">
<form name='f' method='post' action='picasa_post.php'>

<h2>Picasa2Wordpress</h2>
<div>
Attach to exist post: 
<select id="parentId" name="parentId" onchange="chPost(this);">
  <option value="0">New Post</option>
	<?php 
	$pages = get_pages(); 
	foreach ($pages as $pagg) {
		$option = '<option value="'.get_page_link($pagg->ID).'">Page: ';
		$option .= $pagg->post_title;
		$option .= '</option>';
		echo $option;
	}
	?>
	<?php query_posts();?>
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
	<option value="<?php echo $post->ID; ?>">Post :<?php the_title(); ?></option>
	<?php endwhile; ?>
	<?php endif; ?>
</select>
</div>
<!-- New post panel -->
<div id="post-panel" class="panel-wrapper">
	<div class="icon32"><br/></div>
	<h2>Add New Post</h2>
	<div class="post-body">
		<div class="post-body-content">
			<div class="titlediv">
				<div class="titlewrap">
					<input class="text-box" type="text" autocomplete="off" id="post_title" value="" tabindex="1" size="30" name="post_title"/>
				</div>
			</div>
			<div class="contentdiv">
				<div class="contentwrap">
					<textarea class="text-area" id="post_content" tabindex="6" name="post_content" cols="40" rows="1"></textarea>
				</div>
			</div>
		</div>
	</div>
</div>


<h2>Selected images</h2>
<span id="showDesc" class="btn gray">Show Descriptions</span>
<?php
if($_SESSION['POST']['rss'])
{
	$xh = new xmlHandler();
	$nodeNames = array("PHOTO:THUMBNAIL", "PHOTO:IMGSRC", "TITLE","DESCRIPTION");
	$xh->setElementNames($nodeNames);
	$xh->setStartTag("ITEM");
	$xh->setVarsDefault();
	$xh->setXmlParser();
	$xh->setXmlData(stripslashes($_SESSION['POST']['rss']));
	$pData = $xh->xmlParse();
	$br = 0;
	
	$count = 0;
	foreach($pData as $e) { ?>
		<div  class="panel-wrapper">
			<div class="photo-item">
				<div class="photo">
					<img src="<?php echo $e['photo:thumbnail']."?size=-96";?>" width="96" height="96">
				</div>
				<div class="photo-desc">
					<div class="row">
						<span>Title</span><div class="title"><input class="text-box small-text-box" type="text" autocomplete="off" id="<?php echo $count ?>_photo_title" tabindex="1" size="30" name="<?php echo $count ?>_photo_title" value="<?php echo $e['title'];?>"/></div>
					</div>
					<div class="row">
						<span>Caption</span><div class="caption"><input class="text-box small-text-box" type="text" autocomplete="off" id="<?php echo $count ?>_photo_caption" tabindex="1" size="30" name="<?php echo $count ?>_photo_caption" value="<?php echo $e['description'];?>"/></div>
					</div>
					<div class="row">
						<span>Description</span><div class="description"><textarea class="text-area" id="<?php echo $count ?>_photo_desc" tabindex="6" name="<?php echo $count ?>_photo_desc" cols="40" rows="1"></textarea></div>
					</div>
				</div>
				<div style="clear:both"></div>
			</div>
	<?php
			$count++;
	}
	foreach($pData as $e) {
		$large = $e['photo:imgsrc']."?size=1024";
                echo "<input type=hidden name='".$large."'>\r\n";
	}
} else {
	echo "Sorry, but no pictures were received.";
}
?>

	<div style="clear:both"></div>
</div>

<div class="panel-wrapper">Select your upload image size
<INPUT type=radio name=size onclick="chURL('640')">640
<INPUT type=radio name=size onclick="chURL('1024')" CHECKED>1024
<INPUT type=radio name=size onclick="chURL('1600')">1600
<INPUT type=radio name=size onclick="chURL('0')">Original
</div>

<div class="panel-wrapper">
<input class="blue btn" type=submit value="Upload">&nbsp;
<input class="gray btn" type=button value="Discard" onclick="location.href='minibrowser:close';"><br/>
</div>
</form>
</div>
</body>
</html>

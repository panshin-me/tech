
jQuery(document).ready(function()
{
	jQuery("#showDesc").click( function(){
		jQuery(".photo-desc").toggle();
		if(jQuery(this).text() == "Show Descriptions")
			jQuery(this).text("Hide Descriptions");
		else
			jQuery(this).text("Show Descriptions");
	});
});



function chURL(psize){
	jQuery("input[type='hidden']").each(function()
	{
		this.name = this.name.replace(/size=.*/,"size="+psize);
	});
}


function chPost(e){
		var val = jQuery(e).val();
		if(val == "0")
			jQuery("#post-panel").show();
		else
			jQuery("#post-panel").hide();
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace Map
{
    public partial class MapCallibrator : Form
    {
        XmlDocument xmlDoc = new XmlDocument();
        Image mapImage = null;

        public MapCallibrator()
        {
            InitializeComponent();
        }

        private void mainPictureBox_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void mainPictureBox_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void mainPictureBox_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void mainPictureBox_Resize(object sender, EventArgs e)
        {

        }

        private void mainPictureBox_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            openFileDlg.Filter = "JPG files |*.jpg";
            openFileDlg.Title = "Load JPG Map";
            openFileDlg.ShowDialog();
            string path = openFileDlg.FileName;

            mapImage = Image.FromFile(path);
        }

        private void btnLoadTrack_Click(object sender, EventArgs e)
        {
            openFileDlg.Filter =  "GPX files |*.gpx";
            openFileDlg.Title = "Load GPX track";
            openFileDlg.ShowDialog();
            string path = openFileDlg.FileName;

            xmlDoc.Load(path);
            GetPoints();
        }

        private void DrawImages()
        {
            Bitmap offScreenBmp;
            Graphics offScreenDC;
            offScreenBmp = new Bitmap(mainPictureBox.Width, mainPictureBox.Height);
            offScreenDC = Graphics.FromImage(offScreenBmp);

            offScreenDC.Clear(Color.LightGray);
            offScreenDC.DrawImage(mapImage, 0, 0);

            offScreenDC.DrawLines(new Pen(Color.Blue),GetPoints());
        }

        private PointF[] GetPoints()
        {
            //Create an XmlNamespaceManager and add the namespaces for the document.
            XmlNamespaceManager nsmanager = new XmlNamespaceManager(xmlDoc.NameTable);

            //map namespaces to prefixes for querying purposes 
            nsmanager.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
            nsmanager.AddNamespace("def", "http://www.topografix.com/GPX/1/1");

            XmlNodeList xmlNodes = xmlDoc.SelectNodes("/def:gpx/def:trk/def:trkseg/def:trkpt", nsmanager);

            PointF[] pnts = new PointF[xmlNodes.Count];
            float minX = 1000, minY = 1000;
            float maxX = 0, maxY = 0;
            for (int i = 0; i < xmlNodes.Count; i++)
            {
                pnts[i] = new PointF(float.Parse(xmlNodes[i].Attributes["lon"].Value), float.Parse(xmlNodes[i].Attributes["lat"].Value));
                if (minX > pnts[i].X)
                    minX = pnts[i].X;
                if (minY > pnts[i].Y)
                    minY = pnts[i].Y;
                if (maxX < pnts[i].X)
                    maxX = pnts[i].X;
                if (maxY < pnts[i].Y)
                    maxY = pnts[i].Y;
            }

            return pnts;
        }
    }
}
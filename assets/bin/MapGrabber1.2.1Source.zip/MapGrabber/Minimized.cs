using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Drawing2D;

namespace MapGrabber
{
    public partial class Minimized : Form
    {
        public event System.EventHandler OnOk;
        public event System.EventHandler OnCancel;
        public string Status
        {
            set { lblStatus.Text = value; }
        }
        public Bitmap PicMagnifier
        {
            set 
            {
                picMagnifier.Image = value;
            }
        }
        public Bitmap OkButtonImage
        {
            set
            {
                btnOk.Image = value;
            }
        }
        public void ShowMagnifier(bool isShow)
        {
            if (isShow)
            {
                this.Height = 140;
            }
            else
            {
                this.Height = 54;
            }
        }
        public Minimized()
        {
            InitializeComponent();

            Bitmap imageBackground = global::MapGrabber.Properties.Resources.MinimizeBg;
            Color transparentColor = Color.FromArgb(0xFF, 0xFF, 0xFF);

            // Make our form fit the background
            this.Width = imageBackground.Width;
            this.Height = imageBackground.Height;

            // Apply custom region with FF00FF as transparent color
            this.Region = RegionConvert.ConvertFromTransparentBitmap(imageBackground, transparentColor);
            // And set the background to our bitmap to finish everything
            this.BackgroundImage = imageBackground;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (OnOk != null)
                OnOk(this, e);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (OnCancel != null)
                OnCancel(this, e);
        }
    }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Drawing2D;

namespace MapGrabber
{
    public partial class PointForm : Form
    {
        public delegate void RefreshMagnifierHandler(Bitmap bmp);
        public event RefreshMagnifierHandler RefreshMagnifier;
      
        private Point mouseOffset;
        private Point pointOffset;
        private bool isMouseDown = false;
        public MapGrabber.pointType type = MapGrabber.pointType.TopLeft;
        public PointForm(MapGrabber.pointType type)
        {
            this.type = type;
            InitializeComponent();
            // Read the background file
           Bitmap imageBackground = null;
           switch (type)
           {
               case MapGrabber.pointType.FirstPoint:
                   imageBackground = global::MapGrabber.Properties.Resources.FirstPoint;
                   break;
               case MapGrabber.pointType.RightBottom:
                   imageBackground = global::MapGrabber.Properties.Resources.RightBottom;
                   break;
               case MapGrabber.pointType.SecondPoint:
                   imageBackground = global::MapGrabber.Properties.Resources.SecondPoint;
                   break;
               case MapGrabber.pointType.ThirdPoint:
                   imageBackground = global::MapGrabber.Properties.Resources.ThirdPoint;
                   break;
               case MapGrabber.pointType.TopLeft:
                   imageBackground = global::MapGrabber.Properties.Resources.TopLeft;
                   break;
           }
            mouseOffset = new Point(-7, -39);
            pointOffset = new Point(7,39);

            Color transparentColor = Color.FromArgb(0xFF, 0xFF, 0xFF);

            // Make our form fit the background
            this.Width = imageBackground.Width;
            this.Height = imageBackground.Height;

            // Apply custom region with FF00FF as transparent color
            this.Region = RegionConvert.ConvertFromTransparentBitmap(imageBackground, transparentColor);
            // And set the background to our bitmap to finish everything
            this.BackgroundImage = imageBackground;
        }

        void Point_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (isMouseDown)
            {
                Point mousePos = Control.MousePosition;
                if (RefreshMagnifier != null)//152/84
                {
                    Bitmap memoryImage = null;
                    Rectangle rc = new Rectangle(mousePos.X - 25, mousePos.Y - 25, 50, 50);
                    // Create new graphics object using handle to window.
                    using (Graphics graphics = this.CreateGraphics())
                    {
                        memoryImage = new Bitmap(rc.Width,
                                      rc.Height, graphics);

                        using (Graphics memoryGrahics =
                                Graphics.FromImage(memoryImage))
                        {
                            memoryGrahics.CopyFromScreen(rc.X, rc.Y,
                               0, 0, rc.Size, CopyPixelOperation.SourceCopy);
                        }
                        Bitmap result = new Bitmap(150, 84, graphics);
                        using (Graphics g = Graphics.FromImage((Image)result))
                            g.DrawImage(memoryImage, 0, -33, (float)(rc.Width * 3), (float)(rc.Height * 3));
                        RefreshMagnifier(result);
                    }
                }

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);
                Location = mousePos;
            }
        }

        void Point_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            // Changes the isMouseDown field so that the form does
            // not move unless the user is pressing the left mouse button.
            if (e.Button == MouseButtons.Left)
            {
                isMouseDown = false;
            }
            else if (e.Button == MouseButtons.Right)
            {
                this.ParentForm.Show();
            }
        }

        void Point_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isMouseDown = true;
            }
        }

        public Point GetMousePos(Point mousePos)
        {
            mousePos.Offset(mouseOffset.X, mouseOffset.Y);
            return mousePos;
        }
        public Point GetPointPos()
        {
            Point res = this.Location;
            res.Offset(pointOffset);
            return res;
        }
    }
}
namespace MapGrabber
{
    partial class MapGrabber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MapGrabber));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbRightButtomY = new System.Windows.Forms.TextBox();
            this.btnRightButtomCorner = new System.Windows.Forms.Button();
            this.tbRightButtomX = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbLeftTopY = new System.Windows.Forms.TextBox();
            this.btnLeftTopCorner = new System.Windows.Forms.Button();
            this.tbLeftTopX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbNumberY = new System.Windows.Forms.TextBox();
            this.tbNumberX = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbDellayCapture = new System.Windows.Forms.TextBox();
            this.tbDellayScroll = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnBrouwse = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tbMapPath = new System.Windows.Forms.TextBox();
            this.tbDevideY = new System.Windows.Forms.TextBox();
            this.tbDevideX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.gbGPSCall = new System.Windows.Forms.GroupBox();
            this.tbThirdPointY = new System.Windows.Forms.TextBox();
            this.btnThirdPoint = new System.Windows.Forms.Button();
            this.tbThirdPointX = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbThirdPointLon = new System.Windows.Forms.TextBox();
            this.tbThirdPointLat = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbSecondPointY = new System.Windows.Forms.TextBox();
            this.btnSecondPoint = new System.Windows.Forms.Button();
            this.tbSecondPointX = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbFirstPointY = new System.Windows.Forms.TextBox();
            this.btnFirstPoint = new System.Windows.Forms.Button();
            this.tbFirstPointX = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbSecondPointLon = new System.Windows.Forms.TextBox();
            this.tbSecondPointLat = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbFirstPointLon = new System.Windows.Forms.TextBox();
            this.tbFirstPointLat = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbGPSCall = new System.Windows.Forms.CheckBox();
            this.folderBrowserDlg = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.cbShowHide = new System.Windows.Forms.CheckBox();
            this.msMainMenu = new System.Windows.Forms.MenuStrip();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.gbGPSCall.SuspendLayout();
            this.msMainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(153, 507);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(234, 507);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 5;
            this.btnQuit.Text = "Quit";
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbRightButtomY);
            this.groupBox2.Controls.Add(this.btnRightButtomCorner);
            this.groupBox2.Controls.Add(this.tbRightButtomX);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tbLeftTopY);
            this.groupBox2.Controls.Add(this.btnLeftTopCorner);
            this.groupBox2.Controls.Add(this.tbLeftTopX);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 90);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Map Settings";
            // 
            // tbRightButtomY
            // 
            this.tbRightButtomY.Location = new System.Drawing.Point(244, 53);
            this.tbRightButtomY.MaxLength = 5;
            this.tbRightButtomY.Name = "tbRightButtomY";
            this.tbRightButtomY.Size = new System.Drawing.Size(44, 20);
            this.tbRightButtomY.TabIndex = 14;
            // 
            // btnRightButtomCorner
            // 
            this.btnRightButtomCorner.Location = new System.Drawing.Point(139, 50);
            this.btnRightButtomCorner.Name = "btnRightButtomCorner";
            this.btnRightButtomCorner.Size = new System.Drawing.Size(47, 25);
            this.btnRightButtomCorner.TabIndex = 13;
            this.btnRightButtomCorner.Text = "Point";
            this.btnRightButtomCorner.UseVisualStyleBackColor = true;
            this.btnRightButtomCorner.Click += new System.EventHandler(this.btnRightBottomCorner_Click);
            // 
            // tbRightButtomX
            // 
            this.tbRightButtomX.Location = new System.Drawing.Point(192, 53);
            this.tbRightButtomX.MaxLength = 5;
            this.tbRightButtomX.Name = "tbRightButtomX";
            this.tbRightButtomX.Size = new System.Drawing.Size(44, 20);
            this.tbRightButtomX.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Right / Bottom Corner:";
            // 
            // tbLeftTopY
            // 
            this.tbLeftTopY.Location = new System.Drawing.Point(244, 22);
            this.tbLeftTopY.MaxLength = 5;
            this.tbLeftTopY.Name = "tbLeftTopY";
            this.tbLeftTopY.Size = new System.Drawing.Size(44, 20);
            this.tbLeftTopY.TabIndex = 10;
            // 
            // btnLeftTopCorner
            // 
            this.btnLeftTopCorner.Location = new System.Drawing.Point(139, 19);
            this.btnLeftTopCorner.Name = "btnLeftTopCorner";
            this.btnLeftTopCorner.Size = new System.Drawing.Size(47, 25);
            this.btnLeftTopCorner.TabIndex = 9;
            this.btnLeftTopCorner.Text = "Point";
            this.btnLeftTopCorner.UseVisualStyleBackColor = true;
            this.btnLeftTopCorner.Click += new System.EventHandler(this.btnLeftTopCorner_Click);
            // 
            // tbLeftTopX
            // 
            this.tbLeftTopX.Location = new System.Drawing.Point(192, 22);
            this.tbLeftTopX.MaxLength = 5;
            this.tbLeftTopX.Name = "tbLeftTopX";
            this.tbLeftTopX.Size = new System.Drawing.Size(44, 20);
            this.tbLeftTopX.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Left / Top Corner:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbNumberY);
            this.groupBox3.Controls.Add(this.tbNumberX);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.tbDellayCapture);
            this.groupBox3.Controls.Add(this.tbDellayScroll);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(12, 122);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 77);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Capture Settings";
            // 
            // tbNumberY
            // 
            this.tbNumberY.Location = new System.Drawing.Point(244, 45);
            this.tbNumberY.MaxLength = 5;
            this.tbNumberY.Name = "tbNumberY";
            this.tbNumberY.Size = new System.Drawing.Size(44, 20);
            this.tbNumberY.TabIndex = 16;
            // 
            // tbNumberX
            // 
            this.tbNumberX.Location = new System.Drawing.Point(192, 45);
            this.tbNumberX.MaxLength = 5;
            this.tbNumberX.Name = "tbNumberX";
            this.tbNumberX.Size = new System.Drawing.Size(44, 20);
            this.tbNumberX.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Numbers of X / Y Steps:";
            // 
            // tbDellayCapture
            // 
            this.tbDellayCapture.Location = new System.Drawing.Point(244, 19);
            this.tbDellayCapture.MaxLength = 5;
            this.tbDellayCapture.Name = "tbDellayCapture";
            this.tbDellayCapture.Size = new System.Drawing.Size(44, 20);
            this.tbDellayCapture.TabIndex = 13;
            // 
            // tbDellayScroll
            // 
            this.tbDellayScroll.Location = new System.Drawing.Point(192, 19);
            this.tbDellayScroll.MaxLength = 5;
            this.tbDellayScroll.Name = "tbDellayScroll";
            this.tbDellayScroll.Size = new System.Drawing.Size(44, 20);
            this.tbDellayScroll.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Delays Scroll / Capture:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnBrouwse);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.tbMapPath);
            this.groupBox4.Controls.Add(this.tbDevideY);
            this.groupBox4.Controls.Add(this.tbDevideX);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(12, 205);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(297, 78);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Outpu Image Settings";
            // 
            // btnBrouwse
            // 
            this.btnBrouwse.Location = new System.Drawing.Point(225, 45);
            this.btnBrouwse.Name = "btnBrouwse";
            this.btnBrouwse.Size = new System.Drawing.Size(66, 23);
            this.btnBrouwse.TabIndex = 22;
            this.btnBrouwse.Text = "Browse";
            this.btnBrouwse.UseVisualStyleBackColor = true;
            this.btnBrouwse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "Map Path:";
            // 
            // tbMapPath
            // 
            this.tbMapPath.Location = new System.Drawing.Point(68, 47);
            this.tbMapPath.MaxLength = 500;
            this.tbMapPath.Name = "tbMapPath";
            this.tbMapPath.Size = new System.Drawing.Size(157, 20);
            this.tbMapPath.TabIndex = 20;
            // 
            // tbDevideY
            // 
            this.tbDevideY.Location = new System.Drawing.Point(244, 19);
            this.tbDevideY.MaxLength = 5;
            this.tbDevideY.Name = "tbDevideY";
            this.tbDevideY.Size = new System.Drawing.Size(44, 20);
            this.tbDevideY.TabIndex = 19;
            // 
            // tbDevideX
            // 
            this.tbDevideX.Location = new System.Drawing.Point(192, 19);
            this.tbDevideX.MaxLength = 5;
            this.tbDevideX.Name = "tbDevideX";
            this.tbDevideX.Size = new System.Drawing.Size(44, 20);
            this.tbDevideX.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Devide Image X / Y:";
            // 
            // gbGPSCall
            // 
            this.gbGPSCall.Controls.Add(this.tbThirdPointY);
            this.gbGPSCall.Controls.Add(this.btnThirdPoint);
            this.gbGPSCall.Controls.Add(this.tbThirdPointX);
            this.gbGPSCall.Controls.Add(this.label15);
            this.gbGPSCall.Controls.Add(this.tbThirdPointLon);
            this.gbGPSCall.Controls.Add(this.tbThirdPointLat);
            this.gbGPSCall.Controls.Add(this.label16);
            this.gbGPSCall.Controls.Add(this.tbSecondPointY);
            this.gbGPSCall.Controls.Add(this.btnSecondPoint);
            this.gbGPSCall.Controls.Add(this.tbSecondPointX);
            this.gbGPSCall.Controls.Add(this.label13);
            this.gbGPSCall.Controls.Add(this.tbFirstPointY);
            this.gbGPSCall.Controls.Add(this.btnFirstPoint);
            this.gbGPSCall.Controls.Add(this.tbFirstPointX);
            this.gbGPSCall.Controls.Add(this.label12);
            this.gbGPSCall.Controls.Add(this.tbSecondPointLon);
            this.gbGPSCall.Controls.Add(this.tbSecondPointLat);
            this.gbGPSCall.Controls.Add(this.label11);
            this.gbGPSCall.Controls.Add(this.tbFirstPointLon);
            this.gbGPSCall.Controls.Add(this.tbFirstPointLat);
            this.gbGPSCall.Controls.Add(this.label10);
            this.gbGPSCall.Enabled = false;
            this.gbGPSCall.Location = new System.Drawing.Point(12, 312);
            this.gbGPSCall.Name = "gbGPSCall";
            this.gbGPSCall.Size = new System.Drawing.Size(297, 187);
            this.gbGPSCall.TabIndex = 11;
            this.gbGPSCall.TabStop = false;
            this.gbGPSCall.Text = "GPS Callibration";
            // 
            // tbThirdPointY
            // 
            this.tbThirdPointY.Location = new System.Drawing.Point(244, 134);
            this.tbThirdPointY.MaxLength = 5;
            this.tbThirdPointY.Name = "tbThirdPointY";
            this.tbThirdPointY.Size = new System.Drawing.Size(44, 20);
            this.tbThirdPointY.TabIndex = 46;
            // 
            // btnThirdPoint
            // 
            this.btnThirdPoint.Location = new System.Drawing.Point(139, 131);
            this.btnThirdPoint.Name = "btnThirdPoint";
            this.btnThirdPoint.Size = new System.Drawing.Size(47, 25);
            this.btnThirdPoint.TabIndex = 45;
            this.btnThirdPoint.Text = "Point";
            this.btnThirdPoint.UseVisualStyleBackColor = true;
            this.btnThirdPoint.Click += new System.EventHandler(this.btnThirdPoint_Click);
            // 
            // tbThirdPointX
            // 
            this.tbThirdPointX.Location = new System.Drawing.Point(192, 134);
            this.tbThirdPointX.MaxLength = 5;
            this.tbThirdPointX.Name = "tbThirdPointX";
            this.tbThirdPointX.Size = new System.Drawing.Size(44, 20);
            this.tbThirdPointX.TabIndex = 44;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 13);
            this.label15.TabIndex = 43;
            this.label15.Text = "Third Point X / Y:";
            // 
            // tbThirdPointLon
            // 
            this.tbThirdPointLon.Location = new System.Drawing.Point(221, 160);
            this.tbThirdPointLon.MaxLength = 10;
            this.tbThirdPointLon.Name = "tbThirdPointLon";
            this.tbThirdPointLon.Size = new System.Drawing.Size(67, 20);
            this.tbThirdPointLon.TabIndex = 42;
            // 
            // tbThirdPointLat
            // 
            this.tbThirdPointLat.Location = new System.Drawing.Point(148, 160);
            this.tbThirdPointLat.MaxLength = 10;
            this.tbThirdPointLat.Name = "tbThirdPointLat";
            this.tbThirdPointLat.Size = new System.Drawing.Size(67, 20);
            this.tbThirdPointLat.TabIndex = 41;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 163);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "Third Point  Lat / Lon:";
            // 
            // tbSecondPointY
            // 
            this.tbSecondPointY.Location = new System.Drawing.Point(244, 79);
            this.tbSecondPointY.MaxLength = 5;
            this.tbSecondPointY.Name = "tbSecondPointY";
            this.tbSecondPointY.Size = new System.Drawing.Size(44, 20);
            this.tbSecondPointY.TabIndex = 39;
            // 
            // btnSecondPoint
            // 
            this.btnSecondPoint.Location = new System.Drawing.Point(139, 76);
            this.btnSecondPoint.Name = "btnSecondPoint";
            this.btnSecondPoint.Size = new System.Drawing.Size(47, 25);
            this.btnSecondPoint.TabIndex = 38;
            this.btnSecondPoint.Text = "Point";
            this.btnSecondPoint.UseVisualStyleBackColor = true;
            this.btnSecondPoint.Click += new System.EventHandler(this.btnSecondPoint_Click);
            // 
            // tbSecondPointX
            // 
            this.tbSecondPointX.Location = new System.Drawing.Point(192, 79);
            this.tbSecondPointX.MaxLength = 5;
            this.tbSecondPointX.Name = "tbSecondPointX";
            this.tbSecondPointX.Size = new System.Drawing.Size(44, 20);
            this.tbSecondPointX.TabIndex = 37;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "Second Point X / Y:";
            // 
            // tbFirstPointY
            // 
            this.tbFirstPointY.Location = new System.Drawing.Point(244, 24);
            this.tbFirstPointY.MaxLength = 5;
            this.tbFirstPointY.Name = "tbFirstPointY";
            this.tbFirstPointY.Size = new System.Drawing.Size(44, 20);
            this.tbFirstPointY.TabIndex = 35;
            // 
            // btnFirstPoint
            // 
            this.btnFirstPoint.Location = new System.Drawing.Point(139, 21);
            this.btnFirstPoint.Name = "btnFirstPoint";
            this.btnFirstPoint.Size = new System.Drawing.Size(47, 25);
            this.btnFirstPoint.TabIndex = 34;
            this.btnFirstPoint.Text = "Point";
            this.btnFirstPoint.UseVisualStyleBackColor = true;
            this.btnFirstPoint.Click += new System.EventHandler(this.btnFirstPoint_Click);
            // 
            // tbFirstPointX
            // 
            this.tbFirstPointX.Location = new System.Drawing.Point(192, 24);
            this.tbFirstPointX.MaxLength = 5;
            this.tbFirstPointX.Name = "tbFirstPointX";
            this.tbFirstPointX.Size = new System.Drawing.Size(44, 20);
            this.tbFirstPointX.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "First Point X / Y:";
            // 
            // tbSecondPointLon
            // 
            this.tbSecondPointLon.Location = new System.Drawing.Point(221, 105);
            this.tbSecondPointLon.MaxLength = 10;
            this.tbSecondPointLon.Name = "tbSecondPointLon";
            this.tbSecondPointLon.Size = new System.Drawing.Size(67, 20);
            this.tbSecondPointLon.TabIndex = 31;
            // 
            // tbSecondPointLat
            // 
            this.tbSecondPointLat.Location = new System.Drawing.Point(148, 105);
            this.tbSecondPointLat.MaxLength = 10;
            this.tbSecondPointLat.Name = "tbSecondPointLat";
            this.tbSecondPointLat.Size = new System.Drawing.Size(67, 20);
            this.tbSecondPointLat.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 13);
            this.label11.TabIndex = 29;
            this.label11.Text = "Second Point  Lat / Lon:";
            // 
            // tbFirstPointLon
            // 
            this.tbFirstPointLon.Location = new System.Drawing.Point(222, 50);
            this.tbFirstPointLon.MaxLength = 10;
            this.tbFirstPointLon.Name = "tbFirstPointLon";
            this.tbFirstPointLon.Size = new System.Drawing.Size(67, 20);
            this.tbFirstPointLon.TabIndex = 28;
            // 
            // tbFirstPointLat
            // 
            this.tbFirstPointLat.Location = new System.Drawing.Point(149, 50);
            this.tbFirstPointLat.MaxLength = 10;
            this.tbFirstPointLat.Name = "tbFirstPointLat";
            this.tbFirstPointLat.Size = new System.Drawing.Size(67, 20);
            this.tbFirstPointLat.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "First Point Lat / Lon:";
            // 
            // cbGPSCall
            // 
            this.cbGPSCall.AutoSize = true;
            this.cbGPSCall.Location = new System.Drawing.Point(12, 289);
            this.cbGPSCall.Name = "cbGPSCall";
            this.cbGPSCall.Size = new System.Drawing.Size(127, 17);
            this.cbGPSCall.TabIndex = 12;
            this.cbGPSCall.Text = "With GPS Callibration";
            this.cbGPSCall.UseVisualStyleBackColor = true;
            this.cbGPSCall.CheckedChanged += new System.EventHandler(this.cbGPSCall_CheckedChanged);
            // 
            // saveFileDlg
            // 
            this.saveFileDlg.Filter = "Map Grabber Settings Files |*.mgs";
            // 
            // openFileDlg
            // 
            this.openFileDlg.DefaultExt = "mgs";
            this.openFileDlg.Filter = "Map Grabber Settings Files |*.mgs";
            // 
            // cbShowHide
            // 
            this.cbShowHide.AutoSize = true;
            this.cbShowHide.Location = new System.Drawing.Point(197, 289);
            this.cbShowHide.Name = "cbShowHide";
            this.cbShowHide.Size = new System.Drawing.Size(112, 17);
            this.cbShowHide.TabIndex = 16;
            this.cbShowHide.Text = "Show/Hide Points";
            this.cbShowHide.UseVisualStyleBackColor = true;
            this.cbShowHide.CheckedChanged += new System.EventHandler(this.cbShowHide_CheckedChanged);
            // 
            // msMainMenu
            // 
            this.msMainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.msMainMenu.Location = new System.Drawing.Point(0, 0);
            this.msMainMenu.Name = "msMainMenu";
            this.msMainMenu.Size = new System.Drawing.Size(321, 24);
            this.msMainMenu.TabIndex = 17;
            this.msMainMenu.Text = "menuStrip1";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(103, 22);
            this.helpToolStripMenuItem1.Text = "Help";
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // MapGrabber
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(321, 535);
            this.Controls.Add(this.cbShowHide);
            this.Controls.Add(this.cbGPSCall);
            this.Controls.Add(this.gbGPSCall);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.msMainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.msMainMenu;
            this.MinimumSize = new System.Drawing.Size(300, 140);
            this.Name = "MapGrabber";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Map Grabber - Beta 1.2";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.MapGrabber_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gbGPSCall.ResumeLayout(false);
            this.gbGPSCall.PerformLayout();
            this.msMainMenu.ResumeLayout(false);
            this.msMainMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbRightButtomY;
        private System.Windows.Forms.Button btnRightButtomCorner;
        private System.Windows.Forms.TextBox tbRightButtomX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbLeftTopY;
        private System.Windows.Forms.Button btnLeftTopCorner;
        private System.Windows.Forms.TextBox tbLeftTopX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbNumberY;
        private System.Windows.Forms.TextBox tbNumberX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbDellayCapture;
        private System.Windows.Forms.TextBox tbDellayScroll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbDevideY;
        private System.Windows.Forms.TextBox tbDevideX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox gbGPSCall;
        private System.Windows.Forms.TextBox tbSecondPointLon;
        private System.Windows.Forms.TextBox tbSecondPointLat;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbFirstPointLon;
        private System.Windows.Forms.TextBox tbFirstPointLat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbFirstPointY;
        private System.Windows.Forms.Button btnFirstPoint;
        private System.Windows.Forms.TextBox tbFirstPointX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbSecondPointY;
        private System.Windows.Forms.Button btnSecondPoint;
        private System.Windows.Forms.TextBox tbSecondPointX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox cbGPSCall;
        private System.Windows.Forms.Button btnBrouwse;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbMapPath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDlg;
        private System.Windows.Forms.SaveFileDialog saveFileDlg;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private System.Windows.Forms.TextBox tbThirdPointY;
        private System.Windows.Forms.Button btnThirdPoint;
        private System.Windows.Forms.TextBox tbThirdPointX;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbThirdPointLon;
        private System.Windows.Forms.TextBox tbThirdPointLat;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox cbShowHide;
        private System.Windows.Forms.MenuStrip msMainMenu;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;

    }
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.InteropServices;
using System.Threading;
using gma.System.Windows;
using System.Drawing.Imaging;
using System.IO;
using CaptureScreen;
using System.Xml;
using Microsoft.Win32;

namespace Map
{

        public partial class MapGrabber : Form
        {

            #region Variables
            XmlDocument settingsXml = new XmlDocument();
            enum pointType
            {
                East,
                West,
                South,
                North,
                LeftTop,
                RightButtom,
                FirstPoint,
                SecondPoint
            }
            pointType curPointType = pointType.East;
            private UserActivityHook uah;
            bool captureMouse = false;
            float dellayCapture = 0;
            float dellayScroll = 0;
            int numberY = 0;
            int numberX = 0;
            int leftTopY = 0;
            int leftTopX = 0;
            int rightButtomY = 0;
            int rightButtomX = 0;
            int devideY = 0;
            int devideX = 0;
            bool cancelCapture = false;
            bool capturingMode = false;
            bool pauseCapture = false;
            float latFirstPoint = 0;
            float lonFirstPoint = 0;
            float latSecondPoint = 0;
            float lonSecondPoint = 0;
            int firstPointY = 0;
            int firstPointX = 0;
            int secondPointY = 0;
            int secondPointX = 0;
            string mapPath = "";
            #endregion

            public MapGrabber()
            {
                InitializeComponent();
            }

            #region Registry settings
            private string GetLastSettingPath()
            {
                // Attempt to open the key
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\MapGrabber");

                // If the return value is null, the key doesn't exist
                if (key != null && key.GetValue("LastSettingPath") != null)
                {
                    return (string)key.GetValue("LastSettingPath");
                }
                return string.Empty;
            }
            private void SetLastSettingPath(string path)
            {
                // Attempt to open the key
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\MapGrabber");

                // If the return value is null, the key doesn't exist
                if (key == null)
                {
                    // The key doesn't exist; create it / open it
                    key = Registry.CurrentUser.CreateSubKey("Software\\MapGrabber");
                }
                key.SetValue("LastSettingPath", path);
            }
            #endregion

            private void MapGrabber_Load(object sender, System.EventArgs e)
            {
                string settPath = GetLastSettingPath();
                LoadSettings(settPath);

                uah = new UserActivityHook();
                uah.OnMouseActivity += new MouseEventHandler(uah_OnMouseActivity);
                uah.KeyUp += new KeyEventHandler(uah_KeyUp);
            }

            private void LoadSettings(string path)
            {
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    try
                    {
                        settingsXml.Load(path);
                        foreach (XmlNode xmlKey in settingsXml.ChildNodes[0].ChildNodes)
                        {
                            switch(xmlKey.Attributes["name"].Value)
                            {
                                case "dellayCapture":
                                    tbDellayCapture.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "dellayScroll":
                                    tbDellayScroll.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "numberY":
                                    tbNumberY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "numberX":
                                    tbNumberX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "leftTopY":
                                    tbLeftTopY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "leftTopX":
                                    tbLeftTopX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "rightButtomY":
                                    tbRightButtomY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "rightButtomX":
                                    tbRightButtomX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "devideY":
                                    tbDevideY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "devideX":
                                    tbDevideX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "withGPSCallibration":
                                    cbGPSCall.Checked = Convert.ToBoolean(xmlKey.Attributes["value"].Value);
                                    break;
                                case "latFirstPoint":
                                    tbFirstPointLat.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "lonFirstPoint":
                                    tbFirstPointLon.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "latSecondPoint":
                                    tbSecondPointLat.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "lonSecondPoint":
                                    tbSecondPointLon.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "firstPointY":
                                    tbFirstPointY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "firstPointX":
                                    tbFirstPointX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "secondPointY":
                                    tbSecondPointY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "secondPointX":
                                    tbSecondPointX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "mapPath":
                                    tbMapPath.Text = xmlKey.Attributes["value"].Value;
                                    break;
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Error load settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
           }

            private void SaveSettings(string path)
            {
                try
                {
                    settingsXml = new XmlDocument();

                    XmlNode settingsNode = settingsXml.CreateElement("Settings");

                    #region dellayCapture
                    XmlNode keyNode = settingsXml.CreateElement("key");
                    XmlAttribute tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "dellayCapture";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDellayCapture.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region dellayScroll
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "dellayScroll";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDellayScroll.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region numberY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "numberY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbNumberY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region numberX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "numberX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbNumberX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region leftTopY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "leftTopY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbLeftTopY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region leftTopX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "leftTopX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbLeftTopX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region devideY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "devideY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDevideY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region devideX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "devideX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDevideX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region withGPSCallibration
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "withGPSCallibration";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = cbGPSCall.Checked.ToString();
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region latFirstPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "latFirstPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointLat.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region lonFirstPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "lonFirstPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointLon.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region latSecondPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "latSecondPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointLat.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region lonSecondPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "lonSecondPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointLon.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region firstPointY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "firstPointY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region firstPointX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "firstPointX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region secondPointY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "secondPointY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region secondPointX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "secondPointX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region mapPath
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "mapPath";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbMapPath.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    settingsXml.AppendChild(settingsNode);
                    settingsXml.Save(path);
                }
                catch 
                {
                    MessageBox.Show("Error to save settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            #region Map Moving
            /// <summary>
            /// Move map left or right
            /// </summary>
            /// <param name="left"></param>
            private void MoveMapX(bool left)
            {
                int from = left ? leftTopX : rightButtomX;
                int to = left ? rightButtomX : leftTopX;

                PlatformInvokeUSER32.SetCursorPos((uint)from, (uint)leftTopY);
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftDown, 0, 0, 0, new System.IntPtr());
                int curPos = from;
                while (((curPos < to) && left) || ((curPos > to) && !left))
                {
                    curPos += left ? 50 : -50;
                    if (((curPos > to) && left) || ((curPos < to) && !left))
                        curPos = to;

                    Thread.Sleep((int)(dellayScroll * 1000));
                    PlatformInvokeUSER32.SetCursorPos((uint)curPos, (uint)leftTopY);
                }
                Thread.Sleep((int)(dellayScroll * 1000));
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftUp, 0, 0, 0, new System.IntPtr());
            }
            /// <summary>
            /// Move map down
            /// </summary>
            private void MoveMapY()
            {

                PlatformInvokeUSER32.SetCursorPos((uint)leftTopX, (uint)rightButtomY);
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftDown, 0, 0, 0, new System.IntPtr());
                int curPos = rightButtomY;
                while (curPos > leftTopY)
                {
                    curPos -= 50;
                    if (curPos < leftTopY)
                        curPos = leftTopY;

                    Thread.Sleep((int)(dellayScroll * 1000));
                    PlatformInvokeUSER32.SetCursorPos((uint)leftTopX, (uint)curPos);
                }
                Thread.Sleep((int)(dellayScroll * 1000));
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftUp, 0, 0, 0, new System.IntPtr());
            }
            #endregion

            #region Events

            private void btnBrowse_Click(object sender, EventArgs e)
            {
                folderBrowserDlg.ShowDialog();
                tbMapPath.Text = folderBrowserDlg.SelectedPath;
            }

            private void btnLoadSettings_Click(object sender, EventArgs e)
            {
                openFileDlg.ShowDialog();
                if(!string.IsNullOrEmpty(openFileDlg.FileName))
                    LoadSettings(openFileDlg.FileName);
            }

            private void btnSaveSettings_Click(object sender, EventArgs e)
            {
                saveFileDlg.ShowDialog();
                if (!string.IsNullOrEmpty(saveFileDlg.FileName))
                {
                    SaveSettings(saveFileDlg.FileName);
                    SetLastSettingPath(saveFileDlg.FileName);
                }
            }

            private void btnStart_Click(object sender, System.EventArgs e)
            {
                if (isValid())
                {
                    capturingMode = true;
                    this.Hide();
                    Thread thread = new Thread(CaptureMap);
                    thread.IsBackground = true;
                    thread.Start();
                }
            }

            private void btnQuit_Click(object sender, System.EventArgs e)
            {
                this.Close();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            private void btnEastPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.East;
                captureMouse = true;
                this.Hide();
            }

            private void btnWestPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.West;
                captureMouse = true;
                this.Hide();
            }

            private void btnSouthPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.South;
                captureMouse = true;
                this.Hide();
            }

            private void btnNorthPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.North;
                captureMouse = true;
                this.Hide();
            }

            private void btnLeftTopCorner_Click(object sender, EventArgs e)
            {
                curPointType = pointType.LeftTop;
                captureMouse = true;
                this.Hide();
            }

            private void btnRightButtomCorner_Click(object sender, EventArgs e)
            {
                curPointType = pointType.RightButtom;
                captureMouse = true;
                this.Hide();
            }

            private void btnFirstPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.FirstPoint;
                captureMouse = true;
                this.Hide();
            }

            private void btnSecondPoint_Click(object sender, EventArgs e)
            {
                curPointType = pointType.SecondPoint;
                captureMouse = true;
                this.Hide();
            }

            private void cbGPSCall_CheckedChanged(object sender, EventArgs e)
            {
                gbGPSCall.Enabled = cbGPSCall.Checked;
            }

            #endregion

            #region Validate
            /// <summary>
            /// Retrive and validate parameters
            /// </summary>
            /// <returns></returns>
            private bool isValid()
            {
                try
                {
                    dellayCapture = float.Parse(tbDellayCapture.Text);
                    if (dellayCapture <= 0)
                    {
                        MessageBox.Show("Dellay Capture must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    dellayScroll = float.Parse(tbDellayScroll.Text);
                    if (dellayScroll <= 0)
                    {
                        MessageBox.Show("Dellay Scroll must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    numberY = int.Parse(tbNumberY.Text);
                    if (numberY <= 0)
                    {
                        MessageBox.Show("Number steps by Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    numberX = int.Parse(tbNumberX.Text);
                    if (numberX <= 0)
                    {
                        MessageBox.Show("Number steps by X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    leftTopY = int.Parse(tbLeftTopY.Text);
                    if (leftTopY <= 0)
                    {
                        MessageBox.Show("Left top point Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    leftTopX = int.Parse(tbLeftTopX.Text);
                    if (leftTopX <= 0)
                    {
                        MessageBox.Show("Left top point X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    rightButtomY = int.Parse(tbRightButtomY.Text);
                    if (rightButtomY <= 0)
                    {
                        MessageBox.Show("Right buttom point Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    rightButtomX = int.Parse(tbRightButtomX.Text);
                    if (rightButtomX <= 0)
                    {
                        MessageBox.Show("Right buttom point X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    devideY = int.Parse(tbDevideY.Text);
                    if (devideY <= 0)
                    {
                        MessageBox.Show("Devide image by parts Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    devideX = int.Parse(tbDevideX.Text);
                    if (devideX <= 0)
                    {
                        MessageBox.Show("Devide image by parts X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if(leftTopY >= rightButtomY || leftTopX >= rightButtomX)
                    {
                        MessageBox.Show("Left top point of right buttom point not in right places.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    mapPath = tbMapPath.Text;
                    if (string.IsNullOrEmpty(mapPath))
                    {
                        MessageBox.Show("Map path can't be empity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if (!Directory.Exists(mapPath))
                    {
                        MessageBox.Show("Map path not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if (gbGPSCall.Enabled)
                    {
                        latFirstPoint = float.Parse(tbFirstPointLat.Text);
                        lonFirstPoint = float.Parse(tbFirstPointLon.Text);
                        latSecondPoint = float.Parse(tbSecondPointLat.Text);
                        lonSecondPoint = float.Parse(tbSecondPointLon.Text);
                        firstPointY = int.Parse(tbFirstPointY.Text);
                        if (firstPointY < leftTopY || firstPointY > rightButtomY)
                        {
                            MessageBox.Show("First point Y must be between left / top Y and right / buttom Y.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        firstPointX = int.Parse(tbFirstPointX.Text);
                        if (firstPointX < leftTopX || firstPointX > rightButtomX)
                        {
                            MessageBox.Show("First point X must be between left / top X and right / buttom X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        secondPointY = int.Parse(tbSecondPointY.Text);
                        if (secondPointY < leftTopY || secondPointY > rightButtomY)
                        {
                            MessageBox.Show("Second point Y must be between left / top Y and right / buttom Y.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        secondPointX = int.Parse(tbSecondPointX.Text);
                        if (secondPointX < leftTopX || secondPointX > rightButtomX)
                        {
                            MessageBox.Show("Second point X must be between left / top X and right / buttom X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("One of parameters is wrong format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                return true;
            }
            #endregion

            /// <summary>
            /// Main function
            /// Capture map and calculate callibration
            /// </summary>
            private void CaptureMap()
            {
                Graphics g = null;
                //Create rectangel with coordinates of window part to save
                Rectangle part = new Rectangle(leftTopX, leftTopY, rightButtomX - leftTopX, rightButtomY - leftTopY);
                //Matrix with bitmaps
                List<List<Bitmap>> bmpMatrix = new List<List<Bitmap>>();

                for (int y = 0; y < numberY; y++)
                {
                    bmpMatrix.Add(new List<Bitmap>());

                    bool left = ((y % 2) == 0);
                    int from = left ? 0 : numberX-1;
                    int to = left ? numberX : 0;
                    for (int x = from; ((x < to) && left) || ((x >= to) && !left); x += left ? 1 : -1)//left
                    {
                        Thread.Sleep((int)(dellayCapture * 1000));
                        while (pauseCapture)
                        {
                            Thread.Sleep(100);
                        }


                        Bitmap tmpBmp = CaptureScreen.CaptureScreen.GetDesktopImage();
                        Bitmap newBmp = new Bitmap(tmpBmp, part.Size);

                        g = Graphics.FromImage(newBmp);
                        g.DrawImage(tmpBmp, 0,0, part, GraphicsUnit.Pixel);
                        g.Dispose();

                        if (left)
                        {
                            bmpMatrix[y].Add(newBmp);
                        }
                        else
                        {
                            bmpMatrix[y].Insert(0, newBmp);
                        }

                        if (cancelCapture)
                            break;
                        if (((x < to - 1) && left) || ((x >= to+1) && !left)) MoveMapX(!left);
                    }
                    if (cancelCapture)
                        break;
                    if (y < numberY - 1) MoveMapY();
                }


                float geoInPixelX = 0;
                float geoInPixelY = 0;
                if (gbGPSCall.Enabled)
                {
                   geoInPixelX = (lonSecondPoint - lonFirstPoint) / (rightButtomX - leftTopX);
                    geoInPixelY = (latSecondPoint - latFirstPoint) / (rightButtomY - leftTopY);
                }

                for (int partY = 0; partY < numberY; partY += devideY)
                {
                    for (int partX = 0; partX < numberX;partX += devideX )
                    {
                        int imgSizeX = (numberX - partX) > devideX ? devideX : (numberX - partX);
                        int imgSizeY = (numberY - partY) > devideY ? devideY : (numberY - partY);
                        Bitmap img = new Bitmap(part.Width * imgSizeX, part.Height * imgSizeY);
                        for (int screenY = 0; screenY < devideY && (partY + screenY) < numberY; screenY++)
                        {
                            for (int screenX = 0; screenX < devideX && (partX + screenX) < numberX; screenX++)
                            {
                                g = Graphics.FromImage(img);
                                g.DrawImage(bmpMatrix[partY + screenY][partX + screenX], screenX * part.Width, screenY * part.Height);
                                g.Dispose();
                            }
                        }
                        img.Save(mapPath+"\\Map" + partX + partY + ".jpg", ImageFormat.Jpeg);
                        if (gbGPSCall.Enabled)
                        {
                            List<string> callibrationLines = new List<string>();
                            callibrationLines.Add("Map Calibration data file v2.0");
                            callibrationLines.Add("\\Map" + partX + partY + ".jpg");
                            callibrationLines.Add(img.Width.ToString());
                            callibrationLines.Add(img.Height.ToString());
                            callibrationLines.Add((int)(firstPointX - leftTopX) + ";" + (int)(firstPointY - leftTopY) + ";" + (float)(lonFirstPoint + (partX * img.Width * geoInPixelX)) + ";" + (float)(latFirstPoint + (partY * img.Height * geoInPixelY)) + ";");
                            callibrationLines.Add((int)(secondPointX - leftTopX) + ";" + (int)(secondPointY - leftTopY) + ";" + (float)(lonSecondPoint + (partX * img.Width * geoInPixelX)) + ";" + (float)(latSecondPoint + (partY * img.Height * geoInPixelY)) + ";");
                            File.WriteAllLines(mapPath + "\\Map" + partX + partY + ".gmi", callibrationLines.ToArray());
                        }
                    }
                }
                this.Show();
                capturingMode = false;
                cancelCapture = false;
                pauseCapture = false;
            }
            
            #region Global mouse and keyboard events handlers
            void uah_KeyUp(object sender, KeyEventArgs e)
            {
                if(capturingMode)
                {
                    if (e.KeyCode == Keys.Escape)
                    {
                        cancelCapture = true;
                    }
                    if (e.KeyCode == Keys.Space)
                    {
                        pauseCapture = !pauseCapture;
                    }
                }
            }

 
            void uah_OnMouseActivity(object sender, MouseEventArgs e)
            {
                if (captureMouse && e.Clicks > 0)
                {
                    SetPoint(e.X, e.Y);
                }
            }

            private void SetPoint(int x, int y)
            {
                switch (curPointType)
                {
                    case pointType.East:
                        tbEastX.Text = x.ToString();
                        tbEastY.Text = y.ToString();
                        break;
                    case pointType.West:
                        tbWestX.Text = x.ToString();
                        tbWestY.Text = y.ToString();
                        break;
                    case pointType.South:
                        tbSouthX.Text = x.ToString();
                        tbSouthY.Text = y.ToString();
                        break;
                    case pointType.North:
                        tbNorthX.Text = x.ToString();
                        tbNorthY.Text = y.ToString();
                        break;
                    case pointType.LeftTop:
                        tbLeftTopX.Text = x.ToString();
                        tbLeftTopY.Text = y.ToString();
                        break;
                    case pointType.RightButtom:
                        tbRightButtomX.Text = x.ToString();
                        tbRightButtomY.Text = y.ToString();
                        break;
                    case pointType.FirstPoint:
                        tbFirstPointX.Text = x.ToString();
                        tbFirstPointY.Text = y.ToString();
                        break;
                    case pointType.SecondPoint:
                        tbSecondPointX.Text = x.ToString();
                        tbSecondPointY.Text = y.ToString();
                        break;
                }
                captureMouse = false;
                this.Show();
            }
            #endregion
        }
    }

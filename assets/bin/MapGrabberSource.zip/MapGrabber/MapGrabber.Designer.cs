namespace Map
{
    partial class MapGrabber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbNorthY = new System.Windows.Forms.TextBox();
            this.btnNorthPoint = new System.Windows.Forms.Button();
            this.tbNorthX = new System.Windows.Forms.TextBox();
            this.tbSouthY = new System.Windows.Forms.TextBox();
            this.btnSouthPoint = new System.Windows.Forms.Button();
            this.tbSouthX = new System.Windows.Forms.TextBox();
            this.tbWestY = new System.Windows.Forms.TextBox();
            this.btnWestPoint = new System.Windows.Forms.Button();
            this.tbWestX = new System.Windows.Forms.TextBox();
            this.tbEastY = new System.Windows.Forms.TextBox();
            this.btnEastPoint = new System.Windows.Forms.Button();
            this.tbEastX = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbRightButtomY = new System.Windows.Forms.TextBox();
            this.btnRightButtomCorner = new System.Windows.Forms.Button();
            this.tbRightButtomX = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbLeftTopY = new System.Windows.Forms.TextBox();
            this.btnLeftTopCorner = new System.Windows.Forms.Button();
            this.tbLeftTopX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbNumberY = new System.Windows.Forms.TextBox();
            this.tbNumberX = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbDellayCapture = new System.Windows.Forms.TextBox();
            this.tbDellayScroll = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnBrouwse = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tbMapPath = new System.Windows.Forms.TextBox();
            this.tbDevideY = new System.Windows.Forms.TextBox();
            this.tbDevideX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.gbGPSCall = new System.Windows.Forms.GroupBox();
            this.tbSecondPointY = new System.Windows.Forms.TextBox();
            this.btnSecondPoint = new System.Windows.Forms.Button();
            this.tbSecondPointX = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbFirstPointY = new System.Windows.Forms.TextBox();
            this.btnFirstPoint = new System.Windows.Forms.Button();
            this.tbFirstPointX = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbSecondPointLon = new System.Windows.Forms.TextBox();
            this.tbSecondPointLat = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbFirstPointLon = new System.Windows.Forms.TextBox();
            this.tbFirstPointLat = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbGPSCall = new System.Windows.Forms.CheckBox();
            this.folderBrowserDlg = new System.Windows.Forms.FolderBrowserDialog();
            this.btnSaveSettings = new System.Windows.Forms.Button();
            this.btnLoadSettings = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.gbGPSCall.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(153, 496);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(234, 496);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 5;
            this.btnQuit.Text = "Quit";
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbNorthY);
            this.groupBox1.Controls.Add(this.btnNorthPoint);
            this.groupBox1.Controls.Add(this.tbNorthX);
            this.groupBox1.Controls.Add(this.tbSouthY);
            this.groupBox1.Controls.Add(this.btnSouthPoint);
            this.groupBox1.Controls.Add(this.tbSouthX);
            this.groupBox1.Controls.Add(this.tbWestY);
            this.groupBox1.Controls.Add(this.btnWestPoint);
            this.groupBox1.Controls.Add(this.tbWestX);
            this.groupBox1.Controls.Add(this.tbEastY);
            this.groupBox1.Controls.Add(this.btnEastPoint);
            this.groupBox1.Controls.Add(this.tbEastX);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(312, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 146);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Map Controls";
            this.groupBox1.Visible = false;
            // 
            // tbNorthY
            // 
            this.tbNorthY.Location = new System.Drawing.Point(244, 112);
            this.tbNorthY.Name = "tbNorthY";
            this.tbNorthY.Size = new System.Drawing.Size(44, 20);
            this.tbNorthY.TabIndex = 15;
            // 
            // btnNorthPoint
            // 
            this.btnNorthPoint.Location = new System.Drawing.Point(139, 109);
            this.btnNorthPoint.Name = "btnNorthPoint";
            this.btnNorthPoint.Size = new System.Drawing.Size(47, 25);
            this.btnNorthPoint.TabIndex = 14;
            this.btnNorthPoint.Text = "Point";
            this.btnNorthPoint.UseVisualStyleBackColor = true;
            this.btnNorthPoint.Click += new System.EventHandler(this.btnNorthPoint_Click);
            // 
            // tbNorthX
            // 
            this.tbNorthX.Location = new System.Drawing.Point(192, 112);
            this.tbNorthX.Name = "tbNorthX";
            this.tbNorthX.Size = new System.Drawing.Size(44, 20);
            this.tbNorthX.TabIndex = 13;
            // 
            // tbSouthY
            // 
            this.tbSouthY.Location = new System.Drawing.Point(244, 81);
            this.tbSouthY.Name = "tbSouthY";
            this.tbSouthY.Size = new System.Drawing.Size(44, 20);
            this.tbSouthY.TabIndex = 12;
            // 
            // btnSouthPoint
            // 
            this.btnSouthPoint.Location = new System.Drawing.Point(139, 78);
            this.btnSouthPoint.Name = "btnSouthPoint";
            this.btnSouthPoint.Size = new System.Drawing.Size(47, 25);
            this.btnSouthPoint.TabIndex = 11;
            this.btnSouthPoint.Text = "Point";
            this.btnSouthPoint.UseVisualStyleBackColor = true;
            this.btnSouthPoint.Click += new System.EventHandler(this.btnSouthPoint_Click);
            // 
            // tbSouthX
            // 
            this.tbSouthX.Location = new System.Drawing.Point(192, 81);
            this.tbSouthX.Name = "tbSouthX";
            this.tbSouthX.Size = new System.Drawing.Size(44, 20);
            this.tbSouthX.TabIndex = 10;
            // 
            // tbWestY
            // 
            this.tbWestY.Location = new System.Drawing.Point(244, 50);
            this.tbWestY.Name = "tbWestY";
            this.tbWestY.Size = new System.Drawing.Size(44, 20);
            this.tbWestY.TabIndex = 9;
            // 
            // btnWestPoint
            // 
            this.btnWestPoint.Location = new System.Drawing.Point(139, 47);
            this.btnWestPoint.Name = "btnWestPoint";
            this.btnWestPoint.Size = new System.Drawing.Size(47, 25);
            this.btnWestPoint.TabIndex = 8;
            this.btnWestPoint.Text = "Point";
            this.btnWestPoint.UseVisualStyleBackColor = true;
            this.btnWestPoint.Click += new System.EventHandler(this.btnWestPoint_Click);
            // 
            // tbWestX
            // 
            this.tbWestX.Location = new System.Drawing.Point(192, 50);
            this.tbWestX.Name = "tbWestX";
            this.tbWestX.Size = new System.Drawing.Size(44, 20);
            this.tbWestX.TabIndex = 7;
            // 
            // tbEastY
            // 
            this.tbEastY.Location = new System.Drawing.Point(244, 19);
            this.tbEastY.Name = "tbEastY";
            this.tbEastY.Size = new System.Drawing.Size(44, 20);
            this.tbEastY.TabIndex = 6;
            // 
            // btnEastPoint
            // 
            this.btnEastPoint.Location = new System.Drawing.Point(139, 16);
            this.btnEastPoint.Name = "btnEastPoint";
            this.btnEastPoint.Size = new System.Drawing.Size(47, 25);
            this.btnEastPoint.TabIndex = 5;
            this.btnEastPoint.Text = "Point";
            this.btnEastPoint.UseVisualStyleBackColor = true;
            this.btnEastPoint.Click += new System.EventHandler(this.btnEastPoint_Click);
            // 
            // tbEastX
            // 
            this.tbEastX.Location = new System.Drawing.Point(192, 19);
            this.tbEastX.Name = "tbEastX";
            this.tbEastX.Size = new System.Drawing.Size(44, 20);
            this.tbEastX.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "North arrow position:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "South arrow position:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "West arrow position:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "East arrow position:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbRightButtomY);
            this.groupBox2.Controls.Add(this.btnRightButtomCorner);
            this.groupBox2.Controls.Add(this.tbRightButtomX);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tbLeftTopY);
            this.groupBox2.Controls.Add(this.btnLeftTopCorner);
            this.groupBox2.Controls.Add(this.tbLeftTopX);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 90);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Map Settings";
            // 
            // tbRightButtomY
            // 
            this.tbRightButtomY.Location = new System.Drawing.Point(244, 53);
            this.tbRightButtomY.MaxLength = 5;
            this.tbRightButtomY.Name = "tbRightButtomY";
            this.tbRightButtomY.Size = new System.Drawing.Size(44, 20);
            this.tbRightButtomY.TabIndex = 14;
            // 
            // btnRightButtomCorner
            // 
            this.btnRightButtomCorner.Location = new System.Drawing.Point(139, 50);
            this.btnRightButtomCorner.Name = "btnRightButtomCorner";
            this.btnRightButtomCorner.Size = new System.Drawing.Size(47, 25);
            this.btnRightButtomCorner.TabIndex = 13;
            this.btnRightButtomCorner.Text = "Point";
            this.btnRightButtomCorner.UseVisualStyleBackColor = true;
            this.btnRightButtomCorner.Click += new System.EventHandler(this.btnRightButtomCorner_Click);
            // 
            // tbRightButtomX
            // 
            this.tbRightButtomX.Location = new System.Drawing.Point(192, 53);
            this.tbRightButtomX.MaxLength = 5;
            this.tbRightButtomX.Name = "tbRightButtomX";
            this.tbRightButtomX.Size = new System.Drawing.Size(44, 20);
            this.tbRightButtomX.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Right /Buttom Corner:";
            // 
            // tbLeftTopY
            // 
            this.tbLeftTopY.Location = new System.Drawing.Point(244, 22);
            this.tbLeftTopY.MaxLength = 5;
            this.tbLeftTopY.Name = "tbLeftTopY";
            this.tbLeftTopY.Size = new System.Drawing.Size(44, 20);
            this.tbLeftTopY.TabIndex = 10;
            // 
            // btnLeftTopCorner
            // 
            this.btnLeftTopCorner.Location = new System.Drawing.Point(139, 19);
            this.btnLeftTopCorner.Name = "btnLeftTopCorner";
            this.btnLeftTopCorner.Size = new System.Drawing.Size(47, 25);
            this.btnLeftTopCorner.TabIndex = 9;
            this.btnLeftTopCorner.Text = "Point";
            this.btnLeftTopCorner.UseVisualStyleBackColor = true;
            this.btnLeftTopCorner.Click += new System.EventHandler(this.btnLeftTopCorner_Click);
            // 
            // tbLeftTopX
            // 
            this.tbLeftTopX.Location = new System.Drawing.Point(192, 22);
            this.tbLeftTopX.MaxLength = 5;
            this.tbLeftTopX.Name = "tbLeftTopX";
            this.tbLeftTopX.Size = new System.Drawing.Size(44, 20);
            this.tbLeftTopX.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Left / Top Corner:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbNumberY);
            this.groupBox3.Controls.Add(this.tbNumberX);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.tbDellayCapture);
            this.groupBox3.Controls.Add(this.tbDellayScroll);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(12, 108);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 77);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Capture Settings";
            // 
            // tbNumberY
            // 
            this.tbNumberY.Location = new System.Drawing.Point(244, 45);
            this.tbNumberY.MaxLength = 5;
            this.tbNumberY.Name = "tbNumberY";
            this.tbNumberY.Size = new System.Drawing.Size(44, 20);
            this.tbNumberY.TabIndex = 16;
            // 
            // tbNumberX
            // 
            this.tbNumberX.Location = new System.Drawing.Point(192, 45);
            this.tbNumberX.MaxLength = 5;
            this.tbNumberX.Name = "tbNumberX";
            this.tbNumberX.Size = new System.Drawing.Size(44, 20);
            this.tbNumberX.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Numbers of X / Y Steps:";
            // 
            // tbDellayCapture
            // 
            this.tbDellayCapture.Location = new System.Drawing.Point(244, 19);
            this.tbDellayCapture.MaxLength = 5;
            this.tbDellayCapture.Name = "tbDellayCapture";
            this.tbDellayCapture.Size = new System.Drawing.Size(44, 20);
            this.tbDellayCapture.TabIndex = 13;
            // 
            // tbDellayScroll
            // 
            this.tbDellayScroll.Location = new System.Drawing.Point(192, 19);
            this.tbDellayScroll.MaxLength = 5;
            this.tbDellayScroll.Name = "tbDellayScroll";
            this.tbDellayScroll.Size = new System.Drawing.Size(44, 20);
            this.tbDellayScroll.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Delays Scroll / Capture:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnBrouwse);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.tbMapPath);
            this.groupBox4.Controls.Add(this.tbDevideY);
            this.groupBox4.Controls.Add(this.tbDevideX);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(12, 191);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(297, 78);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Outpu Image Settings";
            // 
            // btnBrouwse
            // 
            this.btnBrouwse.Location = new System.Drawing.Point(225, 45);
            this.btnBrouwse.Name = "btnBrouwse";
            this.btnBrouwse.Size = new System.Drawing.Size(66, 23);
            this.btnBrouwse.TabIndex = 22;
            this.btnBrouwse.Text = "Browse";
            this.btnBrouwse.UseVisualStyleBackColor = true;
            this.btnBrouwse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "Map Path:";
            // 
            // tbMapPath
            // 
            this.tbMapPath.Location = new System.Drawing.Point(68, 47);
            this.tbMapPath.MaxLength = 500;
            this.tbMapPath.Name = "tbMapPath";
            this.tbMapPath.Size = new System.Drawing.Size(157, 20);
            this.tbMapPath.TabIndex = 20;
            // 
            // tbDevideY
            // 
            this.tbDevideY.Location = new System.Drawing.Point(244, 19);
            this.tbDevideY.MaxLength = 5;
            this.tbDevideY.Name = "tbDevideY";
            this.tbDevideY.Size = new System.Drawing.Size(44, 20);
            this.tbDevideY.TabIndex = 19;
            // 
            // tbDevideX
            // 
            this.tbDevideX.Location = new System.Drawing.Point(192, 19);
            this.tbDevideX.MaxLength = 5;
            this.tbDevideX.Name = "tbDevideX";
            this.tbDevideX.Size = new System.Drawing.Size(44, 20);
            this.tbDevideX.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Devide Image X / Y:";
            // 
            // gbGPSCall
            // 
            this.gbGPSCall.Controls.Add(this.tbSecondPointY);
            this.gbGPSCall.Controls.Add(this.btnSecondPoint);
            this.gbGPSCall.Controls.Add(this.tbSecondPointX);
            this.gbGPSCall.Controls.Add(this.label13);
            this.gbGPSCall.Controls.Add(this.tbFirstPointY);
            this.gbGPSCall.Controls.Add(this.btnFirstPoint);
            this.gbGPSCall.Controls.Add(this.tbFirstPointX);
            this.gbGPSCall.Controls.Add(this.label12);
            this.gbGPSCall.Controls.Add(this.tbSecondPointLon);
            this.gbGPSCall.Controls.Add(this.tbSecondPointLat);
            this.gbGPSCall.Controls.Add(this.label11);
            this.gbGPSCall.Controls.Add(this.tbFirstPointLon);
            this.gbGPSCall.Controls.Add(this.tbFirstPointLat);
            this.gbGPSCall.Controls.Add(this.label10);
            this.gbGPSCall.Enabled = false;
            this.gbGPSCall.Location = new System.Drawing.Point(12, 298);
            this.gbGPSCall.Name = "gbGPSCall";
            this.gbGPSCall.Size = new System.Drawing.Size(297, 137);
            this.gbGPSCall.TabIndex = 11;
            this.gbGPSCall.TabStop = false;
            this.gbGPSCall.Text = "GPS Callibration";
            // 
            // tbSecondPointY
            // 
            this.tbSecondPointY.Location = new System.Drawing.Point(244, 79);
            this.tbSecondPointY.MaxLength = 5;
            this.tbSecondPointY.Name = "tbSecondPointY";
            this.tbSecondPointY.Size = new System.Drawing.Size(44, 20);
            this.tbSecondPointY.TabIndex = 39;
            // 
            // btnSecondPoint
            // 
            this.btnSecondPoint.Location = new System.Drawing.Point(139, 76);
            this.btnSecondPoint.Name = "btnSecondPoint";
            this.btnSecondPoint.Size = new System.Drawing.Size(47, 25);
            this.btnSecondPoint.TabIndex = 38;
            this.btnSecondPoint.Text = "Point";
            this.btnSecondPoint.UseVisualStyleBackColor = true;
            this.btnSecondPoint.Click += new System.EventHandler(this.btnSecondPoint_Click);
            // 
            // tbSecondPointX
            // 
            this.tbSecondPointX.Location = new System.Drawing.Point(192, 79);
            this.tbSecondPointX.MaxLength = 5;
            this.tbSecondPointX.Name = "tbSecondPointX";
            this.tbSecondPointX.Size = new System.Drawing.Size(44, 20);
            this.tbSecondPointX.TabIndex = 37;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "Second Point X / Y:";
            // 
            // tbFirstPointY
            // 
            this.tbFirstPointY.Location = new System.Drawing.Point(244, 24);
            this.tbFirstPointY.MaxLength = 5;
            this.tbFirstPointY.Name = "tbFirstPointY";
            this.tbFirstPointY.Size = new System.Drawing.Size(44, 20);
            this.tbFirstPointY.TabIndex = 35;
            // 
            // btnFirstPoint
            // 
            this.btnFirstPoint.Location = new System.Drawing.Point(139, 21);
            this.btnFirstPoint.Name = "btnFirstPoint";
            this.btnFirstPoint.Size = new System.Drawing.Size(47, 25);
            this.btnFirstPoint.TabIndex = 34;
            this.btnFirstPoint.Text = "Point";
            this.btnFirstPoint.UseVisualStyleBackColor = true;
            this.btnFirstPoint.Click += new System.EventHandler(this.btnFirstPoint_Click);
            // 
            // tbFirstPointX
            // 
            this.tbFirstPointX.Location = new System.Drawing.Point(192, 24);
            this.tbFirstPointX.MaxLength = 5;
            this.tbFirstPointX.Name = "tbFirstPointX";
            this.tbFirstPointX.Size = new System.Drawing.Size(44, 20);
            this.tbFirstPointX.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "First Point X / Y:";
            // 
            // tbSecondPointLon
            // 
            this.tbSecondPointLon.Location = new System.Drawing.Point(221, 105);
            this.tbSecondPointLon.MaxLength = 10;
            this.tbSecondPointLon.Name = "tbSecondPointLon";
            this.tbSecondPointLon.Size = new System.Drawing.Size(67, 20);
            this.tbSecondPointLon.TabIndex = 31;
            // 
            // tbSecondPointLat
            // 
            this.tbSecondPointLat.Location = new System.Drawing.Point(148, 105);
            this.tbSecondPointLat.MaxLength = 10;
            this.tbSecondPointLat.Name = "tbSecondPointLat";
            this.tbSecondPointLat.Size = new System.Drawing.Size(67, 20);
            this.tbSecondPointLat.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 13);
            this.label11.TabIndex = 29;
            this.label11.Text = "Second Point  Lat / Lon:";
            // 
            // tbFirstPointLon
            // 
            this.tbFirstPointLon.Location = new System.Drawing.Point(222, 50);
            this.tbFirstPointLon.MaxLength = 10;
            this.tbFirstPointLon.Name = "tbFirstPointLon";
            this.tbFirstPointLon.Size = new System.Drawing.Size(67, 20);
            this.tbFirstPointLon.TabIndex = 28;
            // 
            // tbFirstPointLat
            // 
            this.tbFirstPointLat.Location = new System.Drawing.Point(149, 50);
            this.tbFirstPointLat.MaxLength = 10;
            this.tbFirstPointLat.Name = "tbFirstPointLat";
            this.tbFirstPointLat.Size = new System.Drawing.Size(67, 20);
            this.tbFirstPointLat.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "First Point Lat / Lon:";
            // 
            // cbGPSCall
            // 
            this.cbGPSCall.AutoSize = true;
            this.cbGPSCall.Location = new System.Drawing.Point(12, 275);
            this.cbGPSCall.Name = "cbGPSCall";
            this.cbGPSCall.Size = new System.Drawing.Size(127, 17);
            this.cbGPSCall.TabIndex = 12;
            this.cbGPSCall.Text = "With GPS Callibration";
            this.cbGPSCall.UseVisualStyleBackColor = true;
            this.cbGPSCall.CheckedChanged += new System.EventHandler(this.cbGPSCall_CheckedChanged);
            // 
            // btnSaveSettings
            // 
            this.btnSaveSettings.Location = new System.Drawing.Point(161, 19);
            this.btnSaveSettings.Name = "btnSaveSettings";
            this.btnSaveSettings.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSettings.TabIndex = 13;
            this.btnSaveSettings.Text = "Save";
            this.btnSaveSettings.UseVisualStyleBackColor = true;
            this.btnSaveSettings.Click += new System.EventHandler(this.btnSaveSettings_Click);
            // 
            // btnLoadSettings
            // 
            this.btnLoadSettings.Location = new System.Drawing.Point(68, 19);
            this.btnLoadSettings.Name = "btnLoadSettings";
            this.btnLoadSettings.Size = new System.Drawing.Size(75, 23);
            this.btnLoadSettings.TabIndex = 14;
            this.btnLoadSettings.Text = "Load";
            this.btnLoadSettings.UseVisualStyleBackColor = true;
            this.btnLoadSettings.Click += new System.EventHandler(this.btnLoadSettings_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnSaveSettings);
            this.groupBox5.Controls.Add(this.btnLoadSettings);
            this.groupBox5.Location = new System.Drawing.Point(12, 441);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(297, 49);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Settings";
            // 
            // saveFileDlg
            // 
            this.saveFileDlg.Filter = "Map Grabber Settings Files |*.mgs";
            // 
            // openFileDlg
            // 
            this.openFileDlg.DefaultExt = "mgs";
            this.openFileDlg.Filter = "Map Grabber Settings Files |*.mgs";
            // 
            // MapGrabber
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(321, 531);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.cbGPSCall);
            this.Controls.Add(this.gbGPSCall);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MinimumSize = new System.Drawing.Size(300, 140);
            this.Name = "MapGrabber";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Map Grabber - Beta 1.0";
            this.Load += new System.EventHandler(this.MapGrabber_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gbGPSCall.ResumeLayout(false);
            this.gbGPSCall.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbNorthY;
        private System.Windows.Forms.Button btnNorthPoint;
        private System.Windows.Forms.TextBox tbNorthX;
        private System.Windows.Forms.TextBox tbSouthY;
        private System.Windows.Forms.Button btnSouthPoint;
        private System.Windows.Forms.TextBox tbSouthX;
        private System.Windows.Forms.TextBox tbWestY;
        private System.Windows.Forms.Button btnWestPoint;
        private System.Windows.Forms.TextBox tbWestX;
        private System.Windows.Forms.TextBox tbEastY;
        private System.Windows.Forms.Button btnEastPoint;
        private System.Windows.Forms.TextBox tbEastX;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbRightButtomY;
        private System.Windows.Forms.Button btnRightButtomCorner;
        private System.Windows.Forms.TextBox tbRightButtomX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbLeftTopY;
        private System.Windows.Forms.Button btnLeftTopCorner;
        private System.Windows.Forms.TextBox tbLeftTopX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbNumberY;
        private System.Windows.Forms.TextBox tbNumberX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbDellayCapture;
        private System.Windows.Forms.TextBox tbDellayScroll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbDevideY;
        private System.Windows.Forms.TextBox tbDevideX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox gbGPSCall;
        private System.Windows.Forms.TextBox tbSecondPointLon;
        private System.Windows.Forms.TextBox tbSecondPointLat;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbFirstPointLon;
        private System.Windows.Forms.TextBox tbFirstPointLat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbFirstPointY;
        private System.Windows.Forms.Button btnFirstPoint;
        private System.Windows.Forms.TextBox tbFirstPointX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbSecondPointY;
        private System.Windows.Forms.Button btnSecondPoint;
        private System.Windows.Forms.TextBox tbSecondPointX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox cbGPSCall;
        private System.Windows.Forms.Button btnBrouwse;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbMapPath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDlg;
        private System.Windows.Forms.Button btnSaveSettings;
        private System.Windows.Forms.Button btnLoadSettings;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.SaveFileDialog saveFileDlg;
        private System.Windows.Forms.OpenFileDialog openFileDlg;

    }
}


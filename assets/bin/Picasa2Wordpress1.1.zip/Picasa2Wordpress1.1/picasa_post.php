<?php
$postCategory = array();//Default post category
$postStatus = 'draft';//Default post status can be draft,publish,pending
$postParent = 0;//Default post parent
$galleryTag = '[gallery]';//Gallery tag that will be added to your post


require_once('admin.php');
if (!current_user_can('upload_files'))
    wp_die(__('You do not have permission to upload files.'));
if($_FILES) {
    $_POST['action'] = "wp_handle_upload";
    $parentId = $_POST['parentId'];
    $postTitle = $_POST['post_title'];
    $postContent = $_POST['post_content'];
    
    /* Insert new post */
    if($parentId == 0 && trim($postTitle))
    {
		$defaults = array(
			'post_title' => $postTitle,
			'post_content' => $postContent.$galleryTag,
			'post_status' => $postStatus,
			'post_type' => 'post',
			'post_author' => $user_ID,
			'post_parent' => $postParent,
			'menu_order' => 0,
			'post_category' => $postCategory
		);       
        $parentId = wp_insert_post($defaults);
    }
    
    
    /*$parentId = $_POST['parentId'];*/
    foreach($_FILES as $key => $file) {
        if (!empty($file)) {
            $overrides = array('test_form' => false);
            $status = wp_handle_upload($file,$overrides);
            unset($file);
            if (isset($status['error']) ){
                continue;
            }else{
                $url = $status['url'];
                $type = $status['type'];
                $file = $status['file'];
                $filename = basename($file);
                
                $photoTitle = $_POST[$count.'_photo_title'];
                $photoCaption = $_POST[$count.'_photo_caption'];
                $photoDesc = $_POST[$count.'_photo_desc'];
                
                $caption = '';
                $title = '';
                
                if ( $image_meta = @wp_read_image_metadata($file) ) {
                    if ( trim($image_meta['title']) )
                        $title = $image_meta['title'];
                    if ( trim($image_meta['caption']) )
                        $caption = $image_meta['caption'];
                }
                
                if(trim($photoTitle) )
                	$title = $photoTitle;
                else
                	$title = $filename;
                if(trim($photoCaption) )
                	$caption = $photoCaption;
                
                
                $object = array_merge( array(
                'post_title' => $title,
                'post_content' => $photoDesc,
                'post_parent' => $parentId,
                'post_mime_type' => $type,
                'post_excerpt' => $caption,
                'guid' => $url), array());
                
                $id = wp_insert_attachment($object, $file, $parentId);
                if ( !is_wp_error($id) ) {
                    wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $file ) );
                    do_action('wp_create_file_in_uploads', $file, $id); // for replication
                }
            }
        }
        $count++;
    }
	fclose($fh);
}

?>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.InteropServices;
using System.Threading;
//using gma.System.Windows;
using System.Drawing.Imaging;
using System.IO;
using CaptureScreen;
using System.Xml;
using Microsoft.Win32;
using System.Globalization;

namespace MapGrabber
{

        public partial class MapGrabber : Form
        {

            #region Variables
            XmlDocument settingsXml = new XmlDocument();
            public enum pointType
            {
                East,
                West,
                South,
                North,
                TopLeft,
                RightBottom,
                FirstPoint,
                SecondPoint,
                ThirdPoint
            }
            //private UserActivityHook uah;
            bool minimized = false;
            float dellayCapture = 0;
            float dellayScroll = 0;
            int numberY = 0;
            int numberX = 0;
            int leftTopY = 0;
            int leftTopX = 0;
            int rightButtomY = 0;
            int rightButtomX = 0;
            int devideY = 0;
            int devideX = 0;
            bool cancelCapture = false;
            bool capturingMode = false;
            bool pauseCapture = false;
            double latFirstPoint = 0;
            double lonFirstPoint = 0;
            double latSecondPoint = 0;
            double lonSecondPoint = 0;
            double latThirdPoint = 0;
            double lonThirdPoint = 0;
            int firstPointY = 0;
            int firstPointX = 0;
            int secondPointY = 0;
            int secondPointX = 0;
            int thirdPointY = 0;
            int thirdPointX = 0;
            string mapPath = "";
            int fileFormat = 0;
            Minimized minDlg = new Minimized();
            PointForm leftTop = new PointForm(pointType.TopLeft);
            PointForm rightBottom = new PointForm(pointType.RightBottom);
            PointForm firstPoint = new PointForm(pointType.FirstPoint);
            PointForm secondPoint = new PointForm(pointType.SecondPoint);
            PointForm thirdPoint = new PointForm(pointType.ThirdPoint);
            #endregion

            public MapGrabber()
            {
                InitializeComponent();
            }

            #region Registry settings
            private string GetLastSettingPath()
            {
                // Attempt to open the key
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\MapGrabber");

                // If the return value is null, the key doesn't exist
                if (key != null && key.GetValue("LastSettingPath") != null)
                {
                    return (string)key.GetValue("LastSettingPath");
                }
                return string.Empty;
            }
            private void SetLastSettingPath(string path)
            {
                // Attempt to open the key
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\MapGrabber");

                // If the return value is null, the key doesn't exist
                if (key == null)
                {
                    // The key doesn't exist; create it / open it
                    key = Registry.CurrentUser.CreateSubKey("Software\\MapGrabber");
                }
                key.SetValue("LastSettingPath", path);
            }
            #endregion

            private void MapGrabber_Load(object sender, System.EventArgs e)
            {
                minDlg.OnCancel += new EventHandler(minDlg_OnCancel);
                minDlg.OnOk += new EventHandler(minDlg_OnOk);
                firstPoint.RefreshMagnifier += new PointForm.RefreshMagnifierHandler(OnRefreshMagnifier);
                secondPoint.RefreshMagnifier += new PointForm.RefreshMagnifierHandler(OnRefreshMagnifier);
                thirdPoint.RefreshMagnifier += new PointForm.RefreshMagnifierHandler(OnRefreshMagnifier);
                leftTop.Move += new EventHandler(Point_Move);
                rightBottom.Move += new EventHandler(Point_Move);
                firstPoint.Move += new EventHandler(Point_Move);
                secondPoint.Move += new EventHandler(Point_Move);
                thirdPoint.Move += new EventHandler(Point_Move);
                string settPath = GetLastSettingPath();
                cbFileFormat.SelectedIndex = 0;
                LoadSettings(settPath);

                //uah = new UserActivityHook();
                //uah.OnMouseActivity += new MouseEventHandler(uah_OnMouseActivity);
                //uah.KeyUp += new KeyEventHandler(uah_KeyUp);
            }

            private void LoadSettings(string path)
            {
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    try
                    {
                        settingsXml.Load(path);
                        foreach (XmlNode xmlKey in settingsXml.ChildNodes[0].ChildNodes)
                        {
                            switch(xmlKey.Attributes["name"].Value)
                            {
                                case "dellayCapture":
                                    tbDellayCapture.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "dellayScroll":
                                    tbDellayScroll.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "numberY":
                                    tbNumberY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "numberX":
                                    tbNumberX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "leftTopY":
                                    tbLeftTopY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "leftTopX":
                                    tbLeftTopX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "rightButtomY":
                                    tbRightButtomY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "rightButtomX":
                                    tbRightButtomX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "devideY":
                                    tbDevideY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "devideX":
                                    tbDevideX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "withGPSCallibration":
                                    cbGPSCall.Checked = Convert.ToBoolean(xmlKey.Attributes["value"].Value);
                                    break;
                                case "latFirstPoint":
                                    tbFirstPointLat.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "lonFirstPoint":
                                    tbFirstPointLon.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "latSecondPoint":
                                    tbSecondPointLat.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "lonSecondPoint":
                                    tbSecondPointLon.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "latThirdPoint":
                                    tbThirdPointLat.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "lonThirdPoint":
                                    tbThirdPointLon.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "firstPointY":
                                    tbFirstPointY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "firstPointX":
                                    tbFirstPointX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "secondPointY":
                                    tbSecondPointY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "secondPointX":
                                    tbSecondPointX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "thirdPointY":
                                    tbThirdPointY.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "thirdPointX":
                                    tbThirdPointX.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "mapPath":
                                    tbMapPath.Text = xmlKey.Attributes["value"].Value;
                                    break;
                                case "imageFormat":
                                    cbFileFormat.SelectedIndex = Convert.ToInt32(xmlKey.Attributes["value"].Value);
                                    break;
                            }
                        }
                    }
                    catch(Exception exp)
                    {
                        MessageBox.Show("Error load settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
           }

            private void SaveSettings(string path)
            {
                try
                {
                    settingsXml = new XmlDocument();

                    XmlNode settingsNode = settingsXml.CreateElement("Settings");

                    #region dellayCapture
                    XmlNode keyNode = settingsXml.CreateElement("key");
                    XmlAttribute tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "dellayCapture";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDellayCapture.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region dellayScroll
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "dellayScroll";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDellayScroll.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region numberY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "numberY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbNumberY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region numberX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "numberX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbNumberX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region leftTopY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "leftTopY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbLeftTopY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region leftTopX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "leftTopX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbLeftTopX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region rightButtomX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "rightButtomX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbRightButtomX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region devideY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "devideY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDevideY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region devideX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "devideX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbDevideX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region withGPSCallibration
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "withGPSCallibration";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = cbGPSCall.Checked.ToString();
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region latFirstPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "latFirstPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointLat.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region lonFirstPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "lonFirstPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointLon.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region latSecondPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "latSecondPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointLat.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region lonSecondPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "lonSecondPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointLon.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region latThirdPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "latThirdPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbThirdPointLat.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region lonThirdPoint
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "lonThirdPoint";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbThirdPointLon.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region firstPointY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "firstPointY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region firstPointX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "firstPointX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbFirstPointX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region secondPointY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "secondPointY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region secondPointX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "secondPointX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbSecondPointX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region thirdPointY
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "thirdPointY";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbThirdPointY.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region thirdPointX
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "thirdPointX";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbThirdPointX.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region mapPath
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "mapPath";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = tbMapPath.Text;
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    #region imageFormat
                    keyNode = settingsXml.CreateElement("key");
                    tmpAttr = settingsXml.CreateAttribute("name");
                    tmpAttr.Value = "imageFormat";
                    keyNode.Attributes.Append(tmpAttr);

                    tmpAttr = settingsXml.CreateAttribute("value");
                    tmpAttr.Value = cbFileFormat.SelectedIndex.ToString();
                    keyNode.Attributes.Append(tmpAttr);

                    settingsNode.AppendChild(keyNode);
                    #endregion

                    settingsXml.AppendChild(settingsNode);
                    settingsXml.Save(path);
                }
                catch(Exception exp) 
                {
                    MessageBox.Show("Error to save settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            #region Map Moving
            /// <summary>
            /// Move map left or right
            /// </summary>
            /// <param name="left"></param>
            private void MoveMapX(bool left)
            {
                int from = left ? leftTopX : rightButtomX;
                int to = left ? rightButtomX : leftTopX;

                PlatformInvokeUSER32.SetCursorPos((uint)from, (uint)leftTopY);
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftDown, 0, 0, 0, new System.IntPtr());
                int curPos = from;
                while (((curPos < to) && left) || ((curPos > to) && !left))
                {
                    curPos += left ? 50 : -50;
                    if (((curPos > to) && left) || ((curPos < to) && !left))
                        curPos = to;

                    Thread.Sleep((int)(dellayScroll * 1000));
                    PlatformInvokeUSER32.SetCursorPos((uint)curPos, (uint)leftTopY);
                }
                Thread.Sleep((int)(dellayScroll * 1000));
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftUp, 0, 0, 0, new System.IntPtr());
            }
            /// <summary>
            /// Move map down
            /// </summary>
            private void MoveMapY()
            {

                PlatformInvokeUSER32.SetCursorPos((uint)leftTopX, (uint)rightButtomY);
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftDown, 0, 0, 0, new System.IntPtr());
                int curPos = rightButtomY;
                while (curPos > leftTopY)
                {
                    curPos -= 50;
                    if (curPos < leftTopY)
                        curPos = leftTopY;

                    Thread.Sleep((int)(dellayScroll * 1000));
                    PlatformInvokeUSER32.SetCursorPos((uint)leftTopX, (uint)curPos);
                }
                Thread.Sleep((int)(dellayScroll * 1000));
                PlatformInvokeUSER32.mouse_event(PlatformInvokeUSER32.MouseEventLeftUp, 0, 0, 0, new System.IntPtr());
            }
            #endregion

            #region Events

            private void btnBrowse_Click(object sender, EventArgs e)
            {
                folderBrowserDlg.ShowDialog();
                tbMapPath.Text = folderBrowserDlg.SelectedPath;
            }

            private void btnStart_Click(object sender, System.EventArgs e)
            {
                if (isValid())
                {
                    capturingMode = true;
                    this.Hide();
                    ShowPoints(false);
                    minDlg.ShowMagnifier(false);
                    minDlg.Show();
                    minDlg.Top = 0;
                    minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnPause;
                    BackgroundWorker bgWorker = new BackgroundWorker();
                    bgWorker.WorkerReportsProgress = true;
                    bgWorker.DoWork += new DoWorkEventHandler(bgWorker_DoWork);
                    bgWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bgWorker_RunWorkerCompleted);
                    bgWorker.ProgressChanged += new ProgressChangedEventHandler(bgWorker_ProgressChanged);
                    bgWorker.RunWorkerAsync();
                }
            }

            void bgWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
            {
                minDlg.Status = e.UserState.ToString();
            }

            void bgWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
            {
                this.Show();
                minDlg.Hide();
                capturingMode = false;
                cancelCapture = false;
                pauseCapture = false;
            }

            void bgWorker_DoWork(object sender, DoWorkEventArgs e)
            {
                CaptureMap((BackgroundWorker)sender);
            }

            private void btnQuit_Click(object sender, System.EventArgs e)
            {
                this.Close();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }


            private void btnLeftTopCorner_Click(object sender, EventArgs e)
            {
                minimized = true;
                this.Hide();
                minDlg.ShowMagnifier(false);
                minDlg.Show(this);
                minDlg.Location = new Point(minDlg.Location.X, 0);
                minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnOk;
                ShowPoints(true);
                Point pos = ValidateAndGetPoint(pointType.TopLeft);
                if (pos == Point.Empty)
                {
                    pos = Control.MousePosition;
                    leftTop.Show();
                }
                leftTop.Location = leftTop.GetMousePos(pos);
                Cursor.Position = pos;
            }

            private void btnRightBottomCorner_Click(object sender, EventArgs e)
            {
                minimized = true;
                this.Hide();
                minDlg.ShowMagnifier(false);
                minDlg.Show(this);
                minDlg.Location = new Point(minDlg.Location.X, 0);
                minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnOk;
                ShowPoints(true);
                Point pos = ValidateAndGetPoint(pointType.RightBottom);
                if (pos == Point.Empty)
                {
                    pos = Control.MousePosition;
                    rightBottom.Show();
                }
                rightBottom.Location = rightBottom.GetMousePos(pos);
                Cursor.Position = pos;
            }

            private void btnFirstPoint_Click(object sender, EventArgs e)
            {
                minimized = true;
                this.Hide();
                minDlg.ShowMagnifier(true);
                minDlg.Show(this);
                minDlg.Location = new Point(minDlg.Location.X, 0);
                minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnOk;
                ShowPoints(true);
                Point pos = ValidateAndGetPoint(pointType.FirstPoint);
                if (pos == Point.Empty)
                {
                    pos = Control.MousePosition;
                    firstPoint.Show();
                }
                firstPoint.Location = firstPoint.GetMousePos(pos);
                Cursor.Position = pos;
            }

            private void btnSecondPoint_Click(object sender, EventArgs e)
            {
                minimized = true;
                this.Hide();
                minDlg.ShowMagnifier(true);
                minDlg.Show(this);
                minDlg.Location = new Point(minDlg.Location.X, 0);
                minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnOk;
                ShowPoints(true);
                Point pos = ValidateAndGetPoint(pointType.SecondPoint);
                if (pos == Point.Empty)
                {
                    pos = Control.MousePosition;
                    secondPoint.Show();
                }
                secondPoint.Location = secondPoint.GetMousePos(pos);
                Cursor.Position = pos;
            }

            private void btnThirdPoint_Click(object sender, EventArgs e)
            {
                minimized = true;
                this.Hide();
                minDlg.ShowMagnifier(true);
                minDlg.Show(this);
                minDlg.Location = new Point(minDlg.Location.X, 0);
                minDlg.OkButtonImage = global::MapGrabber.Properties.Resources.BtnOk;
                ShowPoints(true);
                Point pos = ValidateAndGetPoint(pointType.ThirdPoint);
                if (pos == Point.Empty)
                {
                    pos = Control.MousePosition;
                    thirdPoint.Show();
                }
                thirdPoint.Location = thirdPoint.GetMousePos(pos);
                Cursor.Position = pos;
            }

            private void cbGPSCall_CheckedChanged(object sender, EventArgs e)
            {
                gbGPSCall.Enabled = cbGPSCall.Checked;
                if (cbGPSCall.Checked)
                {
                    if (cbShowHide.Checked)
                        ShowPoints(true);
                }
                else
                    ShowPoints(false);

            }


            void minDlg_OnOk(object sender, EventArgs e)
            {
                if (capturingMode)
                {
                    pauseCapture = !pauseCapture;
                    minDlg.OkButtonImage = pauseCapture ? global::MapGrabber.Properties.Resources.BtnPlay : global::MapGrabber.Properties.Resources.BtnPause;
                }
                else
                {
                    SetPointsTB();
                    ShowPoints(cbShowHide.Checked);
                    minDlg.Hide();
                    this.Show();
                }
                minimized = false;
            }

            private void SetPointsTB()
            {
                tbLeftTopX.Text = leftTopX.ToString();
                tbLeftTopY.Text = leftTopY.ToString();
                tbRightButtomX.Text = rightButtomX.ToString();
                tbRightButtomY.Text = rightButtomY.ToString();
                tbFirstPointX.Text = firstPointX.ToString();
                tbFirstPointY.Text = firstPointY.ToString();
                tbSecondPointX.Text = secondPointX.ToString();
                tbSecondPointY.Text = secondPointY.ToString();
                tbThirdPointX.Text = thirdPointX.ToString();
                tbThirdPointY.Text = thirdPointY.ToString();
            }

            void minDlg_OnCancel(object sender, EventArgs e)
            {
                if (capturingMode)
                {
                    cancelCapture = true;
                    minDlg.Hide();
                    this.Show();
                }
                else
                {
                    minDlg.Hide();
                    this.Show();
                }
                minimized = false;
                ShowPoints(cbShowHide.Checked);
            }

            void OnRefreshMagnifier(Bitmap bmp)
            {
                minDlg.PicMagnifier = bmp;
            }

            void Point_Move(object sender, EventArgs e)
            {
                PointForm pf = (PointForm)sender;
                switch (pf.type)
                {
                    case pointType.TopLeft:
                        if (minimized)
                        {
                            leftTopX = pf.GetPointPos().X;
                            leftTopY = pf.GetPointPos().Y;
                        }
                        else
                        {
                            tbLeftTopX.Text = pf.GetPointPos().X.ToString();
                            tbLeftTopY.Text = pf.GetPointPos().Y.ToString();
                        }
                        break;
                    case pointType.RightBottom:
                        if (minimized)
                        {
                            rightButtomX = pf.GetPointPos().X;
                            rightButtomY = pf.GetPointPos().Y;
                        }
                        else
                        {
                            tbRightButtomX.Text = pf.GetPointPos().X.ToString();
                            tbRightButtomY.Text = pf.GetPointPos().Y.ToString();
                        }
                        break;
                    case pointType.FirstPoint:
                        if (minimized)
                        {
                            firstPointX = pf.GetPointPos().X;
                            firstPointY = pf.GetPointPos().Y;
                        }
                        else
                        {
                            tbFirstPointX.Text = pf.GetPointPos().X.ToString();
                            tbFirstPointY.Text = pf.GetPointPos().Y.ToString();
                        }
                        break;
                    case pointType.SecondPoint:
                        if (minimized)
                        {
                            secondPointX = pf.GetPointPos().X;
                            secondPointY = pf.GetPointPos().Y;
                        }
                        else
                        {
                            tbSecondPointX.Text = pf.GetPointPos().X.ToString();
                            tbSecondPointY.Text = pf.GetPointPos().Y.ToString();
                        }
                        break;
                    case pointType.ThirdPoint:
                        if (minimized)
                        {
                            thirdPointX = pf.GetPointPos().X;
                            thirdPointY = pf.GetPointPos().Y;
                        }
                        else
                        {
                            tbThirdPointX.Text = pf.GetPointPos().X.ToString();
                            tbThirdPointY.Text = pf.GetPointPos().Y.ToString();
                        }
                        break;
                }
            }

            private void cbShowHide_CheckedChanged(object sender, EventArgs e)
            {
                ShowPoints(cbShowHide.Checked);
            }

            private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
            {
                About about = new About();
                about.ShowDialog(this);
            }

            private void loadToolStripMenuItem_Click(object sender, EventArgs e)
            {
                openFileDlg.ShowDialog();
                if (!string.IsNullOrEmpty(openFileDlg.FileName))
                    LoadSettings(openFileDlg.FileName);
            }

            private void saveToolStripMenuItem_Click(object sender, EventArgs e)
            {
                saveFileDlg.ShowDialog();
                if (!string.IsNullOrEmpty(saveFileDlg.FileName))
                {
                    try
                    {
                        SaveSettings(saveFileDlg.FileName);
                        SetLastSettingPath(saveFileDlg.FileName);
                    }
                    catch
                    {
                        MessageBox.Show("Error to save settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            #endregion

            void ShowPoints(bool isShow)
            {
                if (isShow)
                {
                    Point pos = ValidateAndGetPoint(pointType.TopLeft);
                    if (pos != Point.Empty)
                    {
                        if(!leftTop.Visible)
                            leftTop.Show();
                        leftTop.Location = leftTop.GetMousePos(pos);
                    }
                    pos = ValidateAndGetPoint(pointType.RightBottom);
                    if (pos != Point.Empty)
                    {
                        if (!rightBottom.Visible)
                            rightBottom.Show();
                        rightBottom.Location = rightBottom.GetMousePos(pos);
                    }
                    if (cbGPSCall.Checked)
                    {
                        pos = ValidateAndGetPoint(pointType.FirstPoint);
                        if (pos != Point.Empty)
                        {
                            if (!firstPoint.Visible)
                                firstPoint.Show();
                            firstPoint.Location = firstPoint.GetMousePos(pos);
                        }
                        pos = ValidateAndGetPoint(pointType.SecondPoint);
                        if (pos != Point.Empty)
                        {
                            if (!secondPoint.Visible)
                                secondPoint.Show();
                            secondPoint.Location = secondPoint.GetMousePos(pos);
                        }
                        pos = ValidateAndGetPoint(pointType.ThirdPoint);
                        if (pos != Point.Empty)
                        {
                            if (!thirdPoint.Visible)
                                thirdPoint.Show();
                            thirdPoint.Location = thirdPoint.GetMousePos(pos);
                        }
                    }
                }
                else
                {
                    if (leftTop.Visible)
                        leftTop.Hide();
                    if (rightBottom.Visible)
                        rightBottom.Hide();
                    if (firstPoint.Visible)
                        firstPoint.Hide();
                    if (secondPoint.Visible)
                        secondPoint.Hide();
                    if (thirdPoint.Visible)
                        thirdPoint.Hide();
                }
            }

            #region Validate
            Point ValidateAndGetPoint(pointType pntType)
            {
                try
                {
                    Point res = new Point();
                    switch (pntType)
                    {
                        case pointType.TopLeft:
                            res.X = int.Parse(tbLeftTopX.Text);
                            res.Y = int.Parse(tbLeftTopY.Text);
                            break;
                        case pointType.RightBottom:
                            res.X = int.Parse(tbRightButtomX.Text);
                            res.Y = int.Parse(tbRightButtomY.Text);
                            break;
                        case pointType.FirstPoint:
                            res.X = int.Parse(tbFirstPointX.Text);
                            res.Y = int.Parse(tbFirstPointY.Text);
                            break;
                        case pointType.SecondPoint:
                            res.X = int.Parse(tbSecondPointX.Text);
                            res.Y = int.Parse(tbSecondPointY.Text);
                            break;
                        case pointType.ThirdPoint:
                            res.X = int.Parse(tbThirdPointX.Text);
                            res.Y = int.Parse(tbThirdPointY.Text);
                            break;
                    }
                    if (res.X >= 0 && res.Y >= 0)
                        return res;
                    else
                        return Point.Empty;
                }
                catch
                {
                    return Point.Empty;
                }
            }

            /// <summary>
            /// Retrive and validate parameters
            /// </summary>
            /// <returns></returns>
            private bool isValid()
            {
                try
                {
                    dellayCapture = float.Parse(tbDellayCapture.Text);
                    if (dellayCapture <= 0)
                    {
                        MessageBox.Show("Dellay Capture must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    dellayScroll = float.Parse(tbDellayScroll.Text);
                    if (dellayScroll <= 0)
                    {
                        MessageBox.Show("Dellay Scroll must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    numberY = int.Parse(tbNumberY.Text);
                    if (numberY <= 0)
                    {
                        MessageBox.Show("Number steps by Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    numberX = int.Parse(tbNumberX.Text);
                    if (numberX <= 0)
                    {
                        MessageBox.Show("Number steps by X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    leftTopY = int.Parse(tbLeftTopY.Text);
                    if (leftTopY <= 0)
                    {
                        MessageBox.Show("Left top point Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    leftTopX = int.Parse(tbLeftTopX.Text);
                    if (leftTopX <= 0)
                    {
                        MessageBox.Show("Left top point X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    rightButtomY = int.Parse(tbRightButtomY.Text);
                    if (rightButtomY <= 0)
                    {
                        MessageBox.Show("Right buttom point Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    rightButtomX = int.Parse(tbRightButtomX.Text);
                    if (rightButtomX <= 0)
                    {
                        MessageBox.Show("Right buttom point X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    devideY = int.Parse(tbDevideY.Text);
                    if (devideY <= 0)
                    {
                        MessageBox.Show("Devide image by parts Y must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    devideX = int.Parse(tbDevideX.Text);
                    if (devideX <= 0)
                    {
                        MessageBox.Show("Devide image by parts X must be grate than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if(leftTopY >= rightButtomY || leftTopX >= rightButtomX)
                    {
                        MessageBox.Show("Left top point of right buttom point not in right places.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    mapPath = tbMapPath.Text;
                    fileFormat = cbFileFormat.SelectedIndex;
                    if (string.IsNullOrEmpty(mapPath))
                    {
                        MessageBox.Show("Map path can't be empity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if (!Directory.Exists(mapPath))
                    {
                        MessageBox.Show("Map path not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    if (gbGPSCall.Enabled)
                    {
                        latFirstPoint = double.Parse(tbFirstPointLat.Text);
                        lonFirstPoint = double.Parse(tbFirstPointLon.Text);
                        latSecondPoint = double.Parse(tbSecondPointLat.Text);
                        lonSecondPoint = double.Parse(tbSecondPointLon.Text);
                        latThirdPoint = double.Parse(tbThirdPointLat.Text);
                        lonThirdPoint = double.Parse(tbThirdPointLon.Text);
                        firstPointY = int.Parse(tbFirstPointY.Text);
                        if (firstPointY < leftTopY || firstPointY > rightButtomY)
                        {
                            MessageBox.Show("First point Y must be between left / top Y and right / buttom Y.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        firstPointX = int.Parse(tbFirstPointX.Text);
                        if (firstPointX < leftTopX || firstPointX > rightButtomX)
                        {
                            MessageBox.Show("First point X must be between left / top X and right / buttom X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        secondPointY = int.Parse(tbSecondPointY.Text);
                        if (secondPointY < leftTopY || secondPointY > rightButtomY)
                        {
                            MessageBox.Show("Second point Y must be between left / top Y and right / buttom Y.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        secondPointX = int.Parse(tbSecondPointX.Text);
                        if (secondPointX < leftTopX || secondPointX > rightButtomX)
                        {
                            MessageBox.Show("Second point X must be between left / top X and right / buttom X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        thirdPointY = int.Parse(tbThirdPointY.Text);
                        if (thirdPointY < leftTopY || thirdPointY > rightButtomY)
                        {
                            MessageBox.Show("Third point Y must be between left / top Y and right / buttom Y.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        thirdPointX = int.Parse(tbThirdPointX.Text);
                        if (thirdPointX < leftTopX || thirdPointX > rightButtomX)
                        {
                            MessageBox.Show("Third point X must be between left / top X and right / buttom X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("One of parameters is wrong format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                return true;
            }
            #endregion

            /// <summary>
            /// Main function
            /// Capture map and calculate callibration
            /// </summary>
            private void CaptureMap(BackgroundWorker bgWorker)
            {
                try
                {
                    Graphics g = null;
                    //Create rectangel with coordinates of window part to save
                    Rectangle part = new Rectangle(leftTopX, leftTopY, rightButtomX - leftTopX, rightButtomY - leftTopY);
                    //Matrix with bitmaps
                    List<List<Bitmap>> bmpMatrix = new List<List<Bitmap>>();

                    for (int y = 0; y < numberY; y++)
                    {
                        bmpMatrix.Add(new List<Bitmap>());

                        bool left = ((y % 2) == 0);
                        int from = left ? 0 : numberX - 1;
                        int to = left ? numberX : 0;
                        for (int x = from; ((x < to) && left) || ((x >= to) && !left); x += left ? 1 : -1)//left
                        {
                            bgWorker.ReportProgress(0, "Current Image X: " + x + " Y: " + y);
                            Thread.Sleep((int)(dellayCapture * 1000));
                            while (pauseCapture)
                            {
                                Thread.Sleep(100);
                            }


                            Bitmap tmpBmp = CaptureScreen.CaptureScreen.GetDesktopImage();
                            Bitmap newBmp = new Bitmap(tmpBmp, part.Size);

                            g = Graphics.FromImage(newBmp);
                            g.DrawImage(tmpBmp, 0, 0, part, GraphicsUnit.Pixel);
                            g.Dispose();

                            if (left)
                            {
                                bmpMatrix[y].Add(newBmp);
                            }
                            else
                            {
                                bmpMatrix[y].Insert(0, newBmp);
                            }

                            if (cancelCapture)
                                break;
                            if (((x < to - 1) && left) || ((x >= to + 1) && !left)) MoveMapX(!left);
                        }
                        if (cancelCapture)
                            break;
                        if (y < numberY - 1) MoveMapY();
                    }


                    double geoInPixelX = 0;
                    double geoInPixelY = 0;
                    //Calculate the pixel in 1 lan and lon
                    if (gbGPSCall.Enabled)
                    {
                        double maxLong = lonFirstPoint;
                        int maxX = firstPointX;
                        #region Get max long and x
                        if (maxLong < lonSecondPoint)
                        {
                            maxLong = lonSecondPoint;
                            maxX = secondPointX;
                        }
                        if (maxLong < lonThirdPoint)
                        {
                            maxLong = lonThirdPoint;
                            maxX = thirdPointX;
                        }
                        #endregion

                        double minLong = lonFirstPoint;
                        int minX = firstPointX;
                        #region Get min long and x
                        if (minLong > lonSecondPoint)
                        {
                            minLong = lonSecondPoint;
                            minX = secondPointX;
                        }
                        if (minLong > lonThirdPoint)
                        {
                            minLong = lonThirdPoint;
                            minX = thirdPointX;
                        }
                        #endregion

                        geoInPixelX = (maxLong - minLong) / (maxX - minX);

                        double maxLat = latFirstPoint;
                        int maxY = firstPointY;
                        #region Get max long and y
                        if (maxLat < latSecondPoint)
                        {
                            maxLat = latSecondPoint;
                            maxY = secondPointY;
                        }
                        if (maxLat < latThirdPoint)
                        {
                            maxLat = latThirdPoint;
                            maxY = thirdPointY;
                        }
                        #endregion

                        double minLat = latFirstPoint;
                        int minY = firstPointY;
                        #region Get min lat and y
                        if (minLat > latSecondPoint)
                        {
                            minLat = latSecondPoint;
                            minY = secondPointY;
                        }
                        if (minLat > latThirdPoint)
                        {
                            minLat = latThirdPoint;
                            minY = thirdPointY;
                        }
                        #endregion

                        geoInPixelY = (minLat - maxLat) / (minY - maxY);

                    }
                    string imgExtention = ".jpg";
                    ImageFormat imgFormat = ImageFormat.Jpeg;
                    switch(fileFormat)
                    {
                        case 1://PNG
                            imgExtention = ".png";
                            imgFormat = ImageFormat.Png;
                            break;
                        case 2://TIFF
                            imgExtention = ".tiff";
                            imgFormat = ImageFormat.Tiff;
                            break;
                    }
                    bgWorker.ReportProgress(0, "Saving Images");
                    for (int partY = 0; partY < numberY; partY += devideY)
                    {
                        for (int partX = 0; partX < numberX; partX += devideX)
                        {
                            int imgSizeX = (numberX - partX) > devideX ? devideX : (numberX - partX);
                            int imgSizeY = (numberY - partY) > devideY ? devideY : (numberY - partY);
                            Bitmap img = new Bitmap(part.Width * imgSizeX, part.Height * imgSizeY);
                            for (int screenY = 0; screenY < devideY && (partY + screenY) < numberY; screenY++)
                            {
                                for (int screenX = 0; screenX < devideX && (partX + screenX) < numberX; screenX++)
                                {
                                    g = Graphics.FromImage(img);
                                    g.DrawImage(bmpMatrix[partY + screenY][partX + screenX], screenX * part.Width, screenY * part.Height);
                                    g.Dispose();
                                }
                            }
                            while (File.Exists(mapPath + "\\Map" + partX + partY + imgExtention))
                            {
                                if (MessageBox.Show("Files of map already existing in selected folder. Do you whant select another folder?", "Map Grabber", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                                {
                                    folderBrowserDlg.ShowDialog();
                                    mapPath = tbMapPath.Text = folderBrowserDlg.SelectedPath;
                                }
                                else
                                {
                                    File.Delete(mapPath + "\\Map" + partX + partY + imgExtention);
                                }
                            }
                            img.Save(mapPath + "\\Map" + partX + partY + imgExtention, imgFormat);

                            //Calculate GPS callibration data
                            if (gbGPSCall.Enabled)
                            {
                                //Change the number decemal separator to Dot
                                NumberFormatInfo nfi = new CultureInfo("en-US", false).NumberFormat;

                                List<string> callibrationLines = new List<string>();
                                callibrationLines.Add("Map Calibration data file v2.0");
                                callibrationLines.Add("\\Map" + partX + partY + imgExtention);
                                callibrationLines.Add(img.Width.ToString());
                                callibrationLines.Add(img.Height.ToString());
                                double newLat = latFirstPoint + (partY * img.Height * geoInPixelY);
                                double newLon = lonFirstPoint + (partX * img.Width * geoInPixelX);
                                callibrationLines.Add((int)(firstPointX - leftTopX) + ";" + (int)(firstPointY - leftTopY) + ";" + newLon.ToString(nfi) + ";" + newLat.ToString(nfi) + ";");
                                newLat = latSecondPoint + (partY * img.Height * geoInPixelY);
                                newLon = lonSecondPoint + (partX * img.Width * geoInPixelX);
                                callibrationLines.Add((int)(secondPointX - leftTopX) + ";" + (int)(secondPointY - leftTopY) + ";" + newLon.ToString(nfi) + ";" + newLat.ToString(nfi) + ";");
                                newLat = latThirdPoint + (partY * img.Height * geoInPixelY);
                                newLon = lonThirdPoint + (partX * img.Width * geoInPixelX);
                                callibrationLines.Add((int)(thirdPointX - leftTopX) + ";" + (int)(thirdPointY - leftTopY) + ";" + newLon.ToString(nfi) + ";" + newLat.ToString(nfi) + ";");
                                if (File.Exists(mapPath + "\\Map" + partX + partY + ".gmi"))
                                    File.Delete(mapPath + "\\Map" + partX + partY + ".gmi");
                                File.WriteAllLines(mapPath + "\\Map" + partX + partY + ".gmi", callibrationLines.ToArray());
                            }
                        }
                    }
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Fatal error in map grabbing process: " + exp.Message + ".", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
            {
                System.Diagnostics.Process.Start("http://panshin-programming.blogspot.com/2007/06/map-grabber.html");

            }
            
        }
    }
